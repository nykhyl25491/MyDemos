package sets;

import java.util.HashSet;
import java.util.TreeSet;

import com.app.core.Emp;

public class TestTreeSet {

	public static void main(String[] args) {
		HashSet<Emp> emps = new HashSet<>();
		System.out.println("Added " + emps.add(new Emp(1, "abc", 1000)));
		System.out.println("Added " + emps.add(new Emp(2, "abc2", 2000)));
		System.out.println("Added " + emps.add(new Emp(1, "abc3", 3000)));
		System.out.println("Added " + emps.add(new Emp(2, "abc2", 4000)));
		System.out.println("Added " + emps.add(new Emp(4, "abc", 6000)));
		System.out.println(emps.size());
		System.out.println("Unsorted Set ");
		emps.forEach(System.out::println);
		// display emps as per asc id
		System.out.println("sorted Set as per id ");
		TreeSet<Emp> ts1 = new TreeSet<>(emps);
		ts1.forEach(System.out::println);
		// display emps as per asc sal -- C.O
		System.out.println("sorted Set as per sal ");
		TreeSet<Emp> ts2 = new TreeSet<>((e1, e2) -> ((Double) e1.getSalary()).compareTo(e2.getSalary()));
		ts2.addAll(emps);
		ts2.forEach(System.out::println);

	}

}
