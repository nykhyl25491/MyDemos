package sets;

import java.util.HashSet;

import com.app.core.Emp;

public class TestEmpSet {

	public static void main(String[] args) {
		HashSet<Emp> emps = new HashSet<>();
		System.out.println("Added " + emps.add(new Emp(1, "abc", 1000)));
		System.out.println("Added " + emps.add(new Emp(2, "abc2", 2000)));
		System.out.println("Added " + emps.add(new Emp(1, "abc3", 3000)));
		System.out.println("Added " + emps.add(new Emp(2, "abc2", 4000)));
		System.out.println("Added " + emps.add(new Emp(4, "abc", 6000)));
		System.out.println(emps.size());
		emps.forEach(System.out::println);

	}

}
