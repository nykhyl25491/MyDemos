package com.app.core;

public class Emp implements Comparable<Emp>{
	private int id;
	private String name;
	private double salary;

	public Emp(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}

	/*@Override
	public boolean equals(Object o) {
		System.out.println("in equals");
		if (o instanceof Emp)
			return id == ((Emp) o).id;
		return false;
	}
	@Override
	public int hashCode()
	{
		System.out.println("in hash code");
		return 23*id;
	}*/
	@Override
	public boolean equals(Object o) {
		System.out.println("in equals");
		
		if (o instanceof Emp) {
			Emp e=(Emp) o;
			return id == e.id && name.equals(e.name);
		}
		return false;
	}
	@Override
	public int hashCode()
	{
		System.out.println("in hash code");
		return 23*id+name.hashCode();
	}
	@Override
	public int compareTo(Emp e)
	{
		System.out.println("in comapre to : id n name");
		//sort as per asc id & name
		int ret= ((Integer)id).compareTo(e.id);
		if(ret != 0)
			return ret;
		return name.compareTo(e.name);
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}
	
	
}
