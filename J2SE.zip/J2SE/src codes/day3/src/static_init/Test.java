package static_init;

public class Test {
	static {
		System.out.println("1");
	}
	static {
		System.out.println("2");
	}

	public static void main(String[] args) {
		System.out.println("in main");

	}

}
