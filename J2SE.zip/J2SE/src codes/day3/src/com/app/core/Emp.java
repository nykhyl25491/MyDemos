package com.app.core;

public class Emp {
	private int id;
	private String name,email,deptId;
	//static
	public static int idCounter;
	static {
		idCounter=100;
	}
	//constr
	public Emp(String name,String email,String deptId)
	{
		this.name=name;
		this.email=email;
		this.deptId=deptId;
		id=idCounter++;
	}
	/*public Emp()
	{
		
	}*/
	@Override
	public String toString()
	{
		return id +" "+name+" "+email+" "+deptId;
	}
	
	

}
