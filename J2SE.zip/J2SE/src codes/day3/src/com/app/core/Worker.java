package com.app.core;

public class Worker extends Emp {
	private int nofOfHours;
	private double rate;

	public Worker(String name, String email, String deptId, int no, double rate) {
		super(name, email, deptId);
		nofOfHours = no;
		this.rate = rate;
	}

	@Override
	public String toString() {
		return "Worker " + super.toString() 
		+ " " + nofOfHours + " @ " + rate;
	}

}
