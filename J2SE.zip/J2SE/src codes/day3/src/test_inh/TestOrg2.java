package test_inh;

import java.util.Scanner;

import com.app.core.Mgr;
import com.app.core.Worker;

public class TestOrg2 {

	public static void main(String[] args) {
		
		Object m1 = new Mgr("a1", "a1@gmail","rnd", 23456, 456);
		Object w1=new Worker("a2", "a2@gmail","prod", 23, 40);
		System.out.println("mgr hired...."+m1);//run time poly.
		System.out.println("worker hired...."+w1);
		

	}

}
