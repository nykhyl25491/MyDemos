package test_inh;

import java.util.Scanner;

import com.app.core.Mgr;
import com.app.core.Worker;

public class TestOrg1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter mgr dtls nm em dept basic bonus");
		Mgr m1 = new Mgr(sc.next(), sc.next(), 
				sc.next(), sc.nextDouble(), sc.nextDouble());
		System.out.println("Enter worker dtls nm em dept hrs rate");
		Worker w1=new Worker(sc.next(), sc.next(), 
				sc.next(),sc.nextInt(),sc.nextDouble());
		System.out.println("mgr hired...."+m1);
		System.out.println("worker hired...."+w1);
		if (sc != null)
			sc.close();

	}

}
