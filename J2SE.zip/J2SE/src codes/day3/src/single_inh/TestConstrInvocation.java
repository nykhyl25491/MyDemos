package single_inh;

public class TestConstrInvocation {

	public static void main(String[] args) {
		//sub class object
		B b1=new B();

	}

}
class A
{
	A()
	{   //super();//invokes Object's constr
		System.out.println("1");
	}
}
class B extends A
{
	B()
	{
		//super();//implicitely invoking immediate super cls constr
		System.out.println("2");
	}
}
