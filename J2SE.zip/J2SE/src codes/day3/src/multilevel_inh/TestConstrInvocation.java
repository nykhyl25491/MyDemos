package multilevel_inh;

public class TestConstrInvocation {

	public static void main(String[] args) {
		//sub class object
		C c1=new C();

	}

}
class A
{
	A()
	{   //super();//invokes Object's constr
		System.out.println("1");
	}
}
class B extends A
{
	B()
	{
		//super();//implicitely invoking immediate super cls constr
		System.out.println("2");
	}
}
class C extends B
{
	C()
	{
		//super();
		System.out.println("3");
	}
}
