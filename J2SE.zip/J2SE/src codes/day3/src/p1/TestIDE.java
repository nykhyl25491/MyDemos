package p1;

public class TestIDE {

	public static void main(String[] args) {
		System.out.println("Hello from IDE...."+args[0]);

	}

}
