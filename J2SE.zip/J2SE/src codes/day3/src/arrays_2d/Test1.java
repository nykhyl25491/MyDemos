package arrays_2d;

import java.util.Arrays;

public class Test1 {

	public static void main(String[] args) {
		double[][] vals = new double[3][4];
		// display array contents
		for (int i = 0; i < vals.length; i++) {
			for (int j = 0; j < vals[i].length; j++)
				System.out.print(vals[i][j] + " ");
			System.out.println();
		}
		System.out.println(Arrays.toString(vals));
		System.out.println(Arrays.toString(vals[0]));
		System.out.println(Arrays.deepToString(vals));
		int counter = 1;
		for (int i = 0; i < vals.length; i++)
			for (int j = 0; j < vals[i].length; j++)
				vals[i][j] = counter++;

		System.out.println(Arrays.deepToString(vals));
		// for each
		for (double[] d : vals) {// d=vals[0],d=vals[1]
			for (double d1 : d) { // d1=d[0]....
				System.out.print(d1 + " ");

			}
			System.out.println();
		}
		

	}

}
