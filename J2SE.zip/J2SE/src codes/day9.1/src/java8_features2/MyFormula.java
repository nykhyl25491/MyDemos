package java8_features2;

public class MyFormula implements Formula,Formula2 {

	@Override
	public double calculate(double a) {
		System.out.println("imple abs method");
		return a*a;
	}
	@Override
	public double sqrt(double a, double b) 
	{
		Formula2.super.sqrt(a, b);
		System.out.println("overriding def method");
		return Math.sqrt(a*b);
	}
	

}
