package java8_features2;

public interface Formula2 {
	
	double calculate(double a);
	default double sqrt(double a, double b) {
		System.out.println("def imple 2");
		return Math.sqrt(a - b);
	}
}
