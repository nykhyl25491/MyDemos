package java8_features2;

public class TestDefMethods {

	public static void main(String[] args) {
		Formula f=new MyFormula();//up casting
		System.out.println(f.calculate(10));
		System.out.println(f.sqrt(12, 5));

	}

}
