package java8_features;

public interface Formula {
	double calculate(double a);

	default double sqrt(double a, double b) {
		System.out.println("def imple");
		return Math.sqrt(a + b);
	}
}
