package lambdas2;

public class Test {

	public static void main(String[] args) {
		//res1 --add
		System.out.println(testCompute(10, 20, new Computable() {
			
			@Override
			public double compute(double d1, double d2) {
				// TODO Auto-generated method stub
				return d1+d2;
			}
		}));
		//res 2-  subtraction
		System.out.println(testCompute(10, 20, new Computable() {
			
			@Override
			public double compute(double d1, double d2) {
				// TODO Auto-generated method stub
				return d1-d2;
			}
		}));
		//res 3 --mult
		System.out.println(testCompute(10, 20, new Computable() {
			
			@Override
			public double compute(double d1, double d2) {
				// TODO Auto-generated method stub
				return d1*d2;
			}
		}));

	}
	public static double testCompute(double d1,double d2,Computable ref)
	{
		return ref.compute(d1, d2);
	}

}
