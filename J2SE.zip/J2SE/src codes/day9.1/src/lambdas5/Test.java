package lambdas5;

import java.util.*;
import java.util.function.Consumer;

public class Test {

	public static void main(String[] args) {
		List<Integer> l1=Arrays.asList(1,20,34,45,11,-10);
		//public void forEach(Consumer<? super T> c)
		l1.forEach(new Consumer<Integer>() {

			@Override
			public void accept(Integer arg0) {
				System.out.print(arg0+" ");
				
			}
			
		});
		System.out.println("with lambda");
		l1.forEach((a)->System.out.print(a+" "));
	}

}
