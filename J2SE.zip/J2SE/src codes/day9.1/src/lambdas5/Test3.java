package lambdas5;

import static utils.CollectionUtils.*;
import static utils.ValidationRules.*;

import java.util.Date;
import java.util.List;

import com.app.core.Account;

public class Test3 {

	public static void main(String[] args) {
		try {
			List<Account> l1 = populateData();
			Date d1 = validateDate("1/1/2017");
			l1.removeIf(a -> a.getCreationDate().before(d1));
			//method ref --will be discussed later
			l1.forEach(System.out::println);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
