package lambdas5;

import java.util.*;
import java.util.function.Consumer;

public class Test2 {

	public static void main(String[] args) {
		ArrayList<Integer> l1=new ArrayList<>();
		Collections.addAll(l1, 23,12,134,45,67,120);
		l1.removeIf(i -> i % 2 == 0);
		l1.forEach(i -> System.out.print(i+" "));
	}

}
