package lambdas5;
import static utils.CollectionUtils.*;

import java.util.List;

import com.app.core.Account;

public class ApplyInterest {

	public static void main(String[] args) {
		try {
			List<Account> l1=populateData();
			//apply interest on all a/cs
			double rate=10;
		/*	for(Account a : l1)
				a.applyInterest(rate);
	*/		//replace it by lambda expr
			l1.forEach(a->a.applyInterest(rate));
			//display the list using forEach
			l1.forEach(a->System.out.println(a));
			//later.....
			System.out.println("paraller processing");
			l1.parallelStream().forEach(a->System.out.println(a));
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
