package lambdas1;

public class Test {

	public static void main(String[] args) {
		//res1 --add
		System.out.println(testCompute(10, 20, new MyComputable1()));
		//res 2-  subtraction
		System.out.println(testCompute(10, 20, new MyComputable2()));
		//res 3 --mult
		System.out.println(testCompute(10, 20, new MyComputable3()));

	}
	public static double testCompute(double d1,double d2,Computable ref)
	{
		return ref.compute(d1, d2);
	}

}
