package lambdas1;

@FunctionalInterface
public interface Computable {
	double compute(double d1, double d2);
}
