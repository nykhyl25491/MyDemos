package lambdas1;

public class MyComputable2 implements Computable {

	@Override
	public double compute(double d1, double d2) {
		// TODO Auto-generated method stub
		return d1-d2;
	}

}
