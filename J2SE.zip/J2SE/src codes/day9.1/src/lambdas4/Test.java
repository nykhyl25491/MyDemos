package lambdas4;

import java.util.*;

public class Test {

	public static void main(String[] args) {
		List<Integer> l1=Arrays.asList(1,20,34,45,11,-10);
		/*Collections.sort(l1, new Comparator<Integer>() {

			@Override
			public int compare(Integer arg0, Integer arg1) {
				// TODO Auto-generated method stub
				return arg1.compareTo(arg0);
			}
			
		});*/
		Collections.sort(l1,(a1,a2)-> a2.compareTo(a1));
		System.out.println(l1);

	}

}
