package java8_features3;

public class MyFormula implements Formula {

	@Override
	public double calculate(double a) {
		System.out.println("imple abs method");
		return a*a;
	}
	@Override
	public double sqrt(double a, double b) 
	{
		Formula.super.sqrt(a, b);
	
		System.out.println("overriding def method");
		return Math.sqrt(a*b);
	}
	//re declaring static method
//	@Override
	static void show()
	{
		Formula.show();
		System.out.println("class's static method");
		
	}
	

}
