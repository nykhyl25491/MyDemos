package clnts;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class UserManagementClient {

	public static void main(String[] args) {
		System.out.println("Enter server IP & server port");
		try (Scanner sc = new Scanner(System.in); Socket s1 = new Socket(sc.next(), sc.nextInt())) {
			System.out.println("connected to server.....");
			// attach suitable data srms
			// attach suitable data strms
			ObjectOutputStream out = new ObjectOutputStream(s1.getOutputStream());
			out.flush();// to flush out ser header explicitely to clnt.
			ObjectInputStream in = new ObjectInputStream(s1.getInputStream());
			boolean exit=false;
			while(!exit)
			{
				
				try {
					System.out.println(" 1 : Login 10 : Exit");
					System.out.println("Choose Option");
					switch (sc.nextInt()) {
					case 1:
						System.out.println("Enter email n password for login");
						//send req
						out.writeUTF("login");//cmd
						out.writeUTF(sc.next()); //em
						out.writeUTF(sc.next());//pass
						out.flush();
						System.out.println("clnt sent req...");
						System.out.println("Server sent "+in.readObject());
						break;

					case 10 :exit=true;
						break;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				sc.nextLine();
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("clnt application terminated....");

	}

}
