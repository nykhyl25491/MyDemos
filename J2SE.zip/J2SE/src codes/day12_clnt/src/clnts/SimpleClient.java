package clnts;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class SimpleClient {

	public static void main(String[] args) {
		System.out.println("Enter server IP & server port");
		try(Scanner sc=new Scanner(System.in);
				Socket s1=new Socket(sc.next(), sc.nextInt()))
		{
			System.out.println("connected to server.....");
			//attach suitable data streams for exchanging strings
			DataOutputStream out =new DataOutputStream(s1.getOutputStream());
			DataInputStream in=new DataInputStream(s1.getInputStream());
			//send request
			out.writeUTF("Hello Server , how r u?");
			//display server resp
			System.out.println("Server sent : "+in.readUTF());
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("clnt application terminated....");

	}

}
