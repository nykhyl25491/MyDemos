package strings;

import java.util.Date;

public class TestStringBuilder {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("hello");
		System.out.println(sb + " len " + sb.length() + " capa " + sb.capacity());
		char[] chars = { 65, 66, 67, 68, 69, 70 };

		StringBuilder sb1 = sb.append(chars, 2, 4);
		System.out.println(sb);
		System.out.println(sb1);
		System.out.println(sb == sb1);
		// String
		/*
		 * String s="testing java strings"; s.replace('t', 'p');
		 * System.out.println(s);
		 */
		sb.append(true).append(123.45).append(3456).append(new Date());
		System.out.println(sb +"\n len "+sb.length()+" capa "+sb.capacity());
		sb.setLength(0);
		
		System.out.println("sb="+sb +"\n len "+sb.length()+" capa "+sb.capacity());
		sb.trimToSize();
		System.out.println("sb="+sb +"\n len "+sb.length()+" capa "+sb.capacity());
	}

}
