package test_date;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Test2 {
	

	public static void main(String[] args) {
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		try (Scanner sc = new Scanner(System.in);) {
			System.out.println("Enter DOB");
			Date d1=sdf.parse(sc.next());
			System.out.println("DOB "+sdf.format(d1));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
