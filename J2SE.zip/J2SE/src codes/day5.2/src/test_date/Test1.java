package test_date;

import java.util.Arrays;
import java.util.Date;

public class Test1 {

	public static void main(String[] args) {
		Date d1=new Date();
		System.out.println(d1);
		Date d2=new Date(0);
		System.out.println(d2);
		System.out.println(d1.after(d2));
		System.out.println(d1.compareTo(d2));
		System.out.println("ms elapsed after epoch "+d1.getTime());
		Date[] dates={new Date(),new Date(10000000),new Date(100)};
		Arrays.sort(dates);
		System.out.println(Arrays.toString(dates));

	}

}
