package wrappers;

public class Test {

	public static void main(String[] args) {
		Integer i1=1234;//auto boxing
		int data=i1;//auto un boxing
		i1++;//auto un boxing,inc,auto box
		System.out.println(i1);
		Double d=123.45;//double ---> Double
		double d1=data;//widening conversion
	//	d=123;//int ---> Integer ---X---- Double --peers
		d=(double)123;//double ---> Double
		Number n=23.45F;//float-->Float ----Number
		Object o=123;//int ---Integer --Object
		o=true;//boolean --- Boolean ---- Object		

	}

}
