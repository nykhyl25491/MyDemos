package generics;

import java.util.List;
import java.util.ArrayList;
import com.app.core.*;

public class Test1 {

	public static void main(String[] args) {
		Object o=new SalesMgr();
		Emp e=new Mgr();
		 e =new SalesMgr();
		List<Emp> l1=new ArrayList<>();
		List<Emp> l2=new ArrayList<Mgr>();
		List<Emp> l3=new ArrayList<SalesMgr>();
		List<? extends Emp> l4=new ArrayList<SalesMgr>();
		l4=new ArrayList<Fruit>();

	}

}

