package generics;

import java.util.Collections;
import java.util.LinkedList;

import com.app.core.*;

public class Test3 {

	public static void main(String[] args) {
		/*
		 * public static <T> boolean addAll(Collection<? super T> c, T...
		 * elements)
		 * 
		 * 
		 */
		LinkedList<Emp> l1 = new LinkedList<>();
		Collections.addAll(l1, new Mgr(),new SalesMgr(),new Emp());
				

	}

}
