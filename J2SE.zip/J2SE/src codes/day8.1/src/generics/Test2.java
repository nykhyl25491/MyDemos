package generics;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;

import com.app.core.*;

public class Test2 {

	public static void main(String[] args) {
		HashSet<SalesMgr> hs=new HashSet<>();
		hs.add(new SalesMgr());
		hs.add(new SalesMgr());
		hs.add(new SalesMgr());
		ArrayList<Emp> l1=new ArrayList<>(hs);
		System.out.println(l1);
		LinkedList<Mgr> mgrs=new LinkedList<>();
		mgrs.add(new Mgr());
		mgrs.add(new Mgr());
		ArrayList<Emp> l2=new ArrayList<>(mgrs);
		ArrayList<SalesMgr> l3=new ArrayList<>(mgrs);
		

	}

}
