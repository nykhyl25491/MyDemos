package lists;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import static utils.CollectionUtils.*;

import com.app.core.Account;

public class TestAnoInnerClass {

	public static void main(String[] args) {
		try {
			List<Account> l1 = populateData();
			// sort a/cs by bal
			Collections.sort(l1, new Comparator<Account>() { // begin
				@Override
				public int compare(Account a1, Account a2) {
					System.out.println("in comapre : bal");
					return ((Double) a1.getBalance()).compareTo(a2.getBalance());
				}
			}// end

			);
			System.out.println("A/C sorted as per bal ");
			for (Account a : l1)
				System.out.println(a);

			// sort a/c by date
			Collections.sort(l1, new Comparator<Account>() {

				@Override
				public int compare(Account arg0, Account arg1) {
					System.out.println("in compare : dt");
					return arg0.getCreationDate().compareTo(arg1.getCreationDate());
				}

			});
			System.out.println("A/C sorted as per date ");
			for (Account a : l1)
				System.out.println(a);


		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
