package utils;

import com.app.core.Account;
import java.util.*;
import cust_excs.AccountHandlingException;
import static utils.ValidationRules.*;

public class CollectionUtils {
	public static Map<Integer,Account> populateMap() throws Exception{
		/*
		 * return Arrays.asList(new Account(123, "abc", "saving", 50000, new
		 * Date()), new Account(12, "abc2", "saving", 15000, new Date()), new
		 * Account(150, "abc3", "current", 5000, new Date()));
		 */ 
		HashMap<Integer,Account> hm=new HashMap<>();
		System.out.println(hm.put(123,new Account(123, "abc", "saving", 50000,validateDate("21/3/2018"))));
		System.out.println(hm.put(12,new Account(12, "abc2", "saving", 15000, validateDate("2/11/2015"))));
		System.out.println(hm.put(150,new Account(150, "abc3", "current", 5000, validateDate("25/6/2016"))));
		System.out.println(hm.put(12,new Account(12, "abc4", "current", 3000, validateDate("2/11/2015"))));
		System.out.println(hm.putIfAbsent(150,new Account(150, "abc44", "current", 3000, validateDate("2/11/2015"))));
		System.out.println(hm.size());
		System.out.println(hm);
		return hm;
	}
	public static List<Account> populateData() throws Exception{
		/*
		 * return Arrays.asList(new Account(123, "abc", "saving", 50000, new
		 * Date()), new Account(12, "abc2", "saving", 15000, new Date()), new
		 * Account(150, "abc3", "current", 5000, new Date()));
		 */ ArrayList<Account> l2 = new ArrayList<>();
		l2.add(new Account(123, "abc", "saving", 50000,validateDate("21/3/2018")));
		l2.add(new Account(12, "abc2", "saving", 15000, validateDate("2/11/2015")));
		l2.add(new Account(150, "abc3", "current", 5000, validateDate("25/6/2016")));
		l2.add(new Account(1, "abc4", "current", 3000, validateDate("2/11/2015")));
		return l2;
	}

}
