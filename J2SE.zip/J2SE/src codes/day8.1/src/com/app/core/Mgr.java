package com.app.core;

public class Mgr extends Emp {
}