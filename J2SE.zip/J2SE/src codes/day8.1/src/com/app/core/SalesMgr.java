package com.app.core;

public class SalesMgr extends Mgr {
}