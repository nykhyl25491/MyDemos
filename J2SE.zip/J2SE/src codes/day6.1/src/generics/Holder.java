package generics;

//generic class syntax
public class Holder<T> {
	private T ref;

	public Holder(T ref) {
		this.ref = ref;
	}

	public T getRef() {
		return ref;
	}

	public static void main(String[] args) {
		Holder<Integer> h1=new Holder<>(1234);//int ---> Integer
		int data=h1.getRef();//auto un boxing
		Holder<String> h2=new Holder<>("12345");//NONE
		String ss=h2.getRef();//no conversion
	//	h1=h2;//incompatible types
		System.out.println(h1.getClass().getName());
		System.out.println(h2.getClass().getName());
		
		
		
	}

}
