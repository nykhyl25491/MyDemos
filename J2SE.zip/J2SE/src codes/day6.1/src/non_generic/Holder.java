package non_generic;

public class Holder {
	private Object ref;
	public Holder(Object ref) {
		this.ref=ref;
	}
	public Object getRef() {
		return ref;
	}


	public static void main(String[] args) {
		Holder h1=new Holder(1234);//int ---> Integer -- Object
		int data=(int)h1.getRef();//explicit type casting required
		Holder h2=new Holder("1234");//Stirng --> Object
		String s=(String)h2.getRef();//explicit type casting required
		h1=h2;
		data=(int)h1.getRef();
		System.out.println(data);
	}

}
