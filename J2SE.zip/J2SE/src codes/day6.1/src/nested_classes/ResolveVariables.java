package nested_classes;

class ResolveVariables {
	private int x = 7;

	public void makeInner() {
		MyInner in = new MyInner();
		in.seeOuter(10);
	}

	class MyInner {
		int x = 8;

		public void seeOuter(int x) {
			System.out.println("Local x is " + x);
			System.out.println("Inner class's x is " + this.x);
			System.out.println("Outer class's x is " + ResolveVariables.this.x);
		}
	}

	public static void main(String[] args) {
		ResolveVariables.MyInner inner = new ResolveVariables().new MyInner();
		inner.seeOuter(9);
	}
}