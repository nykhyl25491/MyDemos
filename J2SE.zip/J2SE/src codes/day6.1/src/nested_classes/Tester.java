package nested_classes;

public class Tester {

	public static void main(String[] args) {
		Emp e1=new Emp(123,"abc");
		Emp.Address adr=e1.new Address("pune", "IN");
		System.out.println(e1);
		System.out.println(adr);

	}

}
