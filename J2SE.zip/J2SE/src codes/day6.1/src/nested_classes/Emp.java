package nested_classes;

public class Emp {
	private int id;
	private String name;
	
	public Emp(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	void test()
	{
		//city
		Address a=new Address("city1", "country1");
		System.out.println(a.city);
	}
	static void testMe()
	{
		//city
		Emp.Address e1=new Emp(101,"aa").new Address("city1", "country1");
		System.out.println(e1.city);
		
	}
	
	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + "]";
	}

	//inner class def
	class Address {
		private String city,country;
		private static final int data=1234;//since JDK 1.8 ++

		public Address(String city, String country) {
			super();
			this.city = city;
			this.country = country;
		}
		void show()
		{
			System.out.println("id="+id+" name "+name);
		}
		/*static void check()
		{
			
		}*/
		@Override
		public String toString() {
			return "Address [city=" + city + ", country=" + country + "]";
		}
		
		
	}

}
