package lists;

import java.util.ArrayList;
import java.util.Arrays;

public class IntegerList {

	public static void main(String[] args) {
		// create empty AL to hold integer type of refs
		ArrayList<Integer> l1 = new ArrayList<>();
		// populate AL
		int[] data = { 10, 2, 3, 100, -10, 10, 2, 3, 2 };
		for (int i : data) // NONE
			l1.add(i);// auto boxing l1.add(new Integer(i));
	//	l1.add(0, null);
		// display AL -- toString
		System.out.println("AL via toString "+l1);
		// display AL --for --each
		System.out.println("AL via for-each");
		for(int i : l1) //auto un boxing
			System.out.printf("%d ",i);
		System.out.println();
		System.out.println("AL contents via for loop");
		// display AL --for loop
		for(int i=0;i<l1.size();i++)
			System.out.print(l1.get(i)+" ");
		// insert elem
		l1.add(0,1234);
		System.out.println(l1);
		// remove
		l1.remove(l1.size()-2);
		System.out.println(l1);
		// search for element
		System.out.println(l1.contains(1090)? "Exists":"Doesn't Exist");
		// bulk add
		ArrayList<Integer> l2=new ArrayList<>();
		l2.addAll(l1);
		System.out.println(l2);
		// conversion to array.
		Integer[] refs=new Integer[l1.size()];
		Integer[] ints=l1.toArray(refs);
		System.out.println(Arrays.toString(ints));
		

	}

}
