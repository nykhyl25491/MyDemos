package lists;

import java.util.ArrayList;
import java.util.Scanner;
import static com.app.core.Account.sdf;

import com.app.core.Account;

public class CreateAccount {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			// create empty AL of suitable type
			ArrayList<Account> l1 = new ArrayList<>();
			// accept a/c data from user & populate AL
			for (int i = 0; i < 3; i++) {
				System.out.println("Enter a/c info -- id nm type bal date");
				l1.add(new Account(sc.nextInt(), sc.next(), 
						sc.next(), sc.nextDouble(), 
						sdf.parse(sc.next())));
			}
			//display a/c info --for each
			for(Account a  : l1)
				System.out.println(a);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
