package utils;

import java.util.*;

import com.app.core.Account;

public class CollectionUtils {
	public static List<Account> populateData() {
		return Arrays.asList(new Account(123, "abc", "saving", 50000, new Date()),
				new Account(12, "abc2", "saving", 15000, new Date()),
				new Account(150, "abc3", "current", 5000, new Date()));
	}
}
