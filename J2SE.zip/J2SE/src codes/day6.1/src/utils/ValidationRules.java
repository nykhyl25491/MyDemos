package utils;

import cust_excs.*;

public class ValidationRules {
	public static final double MIN_BALANCE;
	static {
		MIN_BALANCE = 1000;
	}

	// validate balance
	public static void validateBalance(double bal) throws AccountHandlingException {
		if (bal < MIN_BALANCE)
			throw new AccountHandlingException("Insufficient Funds!!!!");
	}

}
