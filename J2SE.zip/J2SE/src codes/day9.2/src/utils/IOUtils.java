package utils;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.List;

import com.app.core.Emp;

public class IOUtils {
	public static void storeEmpInfo(List<Emp> l1, String file) throws Exception
	{
		//create chain of resources
		try(PrintWriter pw=new PrintWriter(new FileWriter(file)))
		{
			l1.forEach(e -> pw.println(e));
		}
	}
}
