package utils;

import java.util.*;

import com.app.core.Emp;

public class CollectionUtils {
	// rets AL<Emp>
	public static List<Emp> populateData() {
		ArrayList<Emp> l1 = new ArrayList<>();
		Collections.addAll(l1, new Emp(1, "abc", 1000), new Emp(23, "abc2", 5000), new Emp(11, "abc3", 11000),
				new Emp(16, "abc4", 6000));
		return l1;
	}
}
