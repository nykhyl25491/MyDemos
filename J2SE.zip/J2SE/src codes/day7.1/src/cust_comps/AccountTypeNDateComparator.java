package cust_comps;

import java.util.Comparator;

import com.app.core.Account;

public class AccountTypeNDateComparator implements Comparator<Account> {

	@Override
	public int compare(Account a1, Account a2) {
		System.out.println("in compare of acc type n date ");
		int ret = a1.getType().compareTo(a2.getType());
		if (ret != 0)
			return ret;
		return a1.getCreationDate().compareTo(a2.getCreationDate());
	}

}
