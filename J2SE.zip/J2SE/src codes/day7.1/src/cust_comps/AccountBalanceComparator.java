package cust_comps;

import java.util.Comparator;

import com.app.core.Account;

public class AccountBalanceComparator implements Comparator<Account> {
	@Override
	public int compare(Account a1,Account a2)
	{
		System.out.println("in compare : Acct bal comp");
		return ((Double)a1.getBalance()).compareTo(a2.getBalance());
	}

}
