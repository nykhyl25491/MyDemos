package iterators;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Test5 {

	public static void main(String[] args) {
		List<Integer> l1=new ArrayList<>();
		l1.add(10);
		l1.add(1);
		l1.add(200);
		l1.add(123);
		//attach list iterator for reverse traversing
		ListIterator<Integer> litr=l1.listIterator(l1.size());
		System.out.println(litr.getClass().getName());
		while(litr.hasPrevious())
			System.out.print(litr.previous()+" ");
		System.out.println(litr.previous());
		
		

	}

}
