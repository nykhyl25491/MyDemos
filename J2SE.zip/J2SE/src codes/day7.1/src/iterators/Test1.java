package iterators;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test1 {

	public static void main(String[] args) {
		List<Integer> l1=new ArrayList<>();
		l1.add(10);
		l1.add(1);
		l1.add(200);
		l1.add(123);
		//display list contents using Iterator
		//attach iterator
		Iterator<Integer> itr=l1.iterator();
		System.out.println(itr.getClass().getName());
		while(itr.hasNext())
			System.out.println(itr.next());
	//	System.out.println(itr.next());
		System.out.println(l1.get(l1.size()));
		
		

	}

}
