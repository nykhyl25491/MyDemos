package lists;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;
import static com.app.core.Account.sdf;
import static utils.CollectionUtils.*;

import com.app.core.Account;

import cust_comps.AccountBalanceComparator;
import cust_comps.AccountTypeNDateComparator;
import cust_excs.AccountHandlingException;

public class SortAccounts {

	public static void main(String[] args) {
		try {
			List<Account> l1 = populateData();
			// display a/c info --for each
			System.out.println("Orig list");
			for (Account a : l1)
				System.out.println(a);
			Collections.sort(l1);
			System.out.println("Sorted list as per N.O -- acct id");
			for (Account a : l1)
				System.out.println(a);
			// sort a/cs as per balance w/o touching UDT
			Collections.sort(l1, new AccountBalanceComparator());
			System.out.println("Sorted list as per C.O  -- bal");
			for (Account a : l1)
				System.out.println(a);

			// sort a/cs as per type n date w/o touching UDT
			Collections.sort(l1, new AccountTypeNDateComparator());
			System.out.println("Sorted list as per C.O  -- type n date");
			for (Account a : l1)
				System.out.println(a);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
