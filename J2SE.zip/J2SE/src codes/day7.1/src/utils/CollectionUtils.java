package utils;

import java.util.*;

import com.app.core.Account;

import cust_excs.AccountHandlingException;
import static utils.ValidationRules.*;

public class CollectionUtils {
	public static List<Account> populateData() throws Exception{
		/*
		 * return Arrays.asList(new Account(123, "abc", "saving", 50000, new
		 * Date()), new Account(12, "abc2", "saving", 15000, new Date()), new
		 * Account(150, "abc3", "current", 5000, new Date()));
		 */ ArrayList<Account> l2 = new ArrayList<>();
		l2.add(new Account(123, "abc", "saving", 50000,validateDate("21/3/2018")));
		l2.add(new Account(12, "abc2", "saving", 15000, validateDate("2/11/2015")));
		l2.add(new Account(150, "abc3", "current", 5000, validateDate("25/6/2016")));
		l2.add(new Account(1, "abc4", "current", 3000, validateDate("2/11/2015")));
		return l2;
	}

	// finder by PK
	public static Account findByPrimaryKey(int acctId, List<Account> l1) throws Exception {
		// id --Account
		Account a = new Account(acctId);
		int index = l1.indexOf(a);
		if (index == -1)
			throw new AccountHandlingException("Invalid A/C ID");
		return l1.get(index);
	}
}
