class Hello {
   public static void main(String[] args)
   {
// System --- java.lang.System --- class from java.lang package(= collection of functionally similar classes)
// out --- static data member of System class ---std out 
// data type --- java.io.PrintStream
//PrintStream -- class -- print/println/printf
     System.out.println("Welcome 2 Java!!!!!");
	System.out.print("Hello , "+args[0]);
   }
}
class A
{
}
class B
{
}
