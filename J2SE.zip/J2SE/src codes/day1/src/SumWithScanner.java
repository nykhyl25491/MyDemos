import java.util.Scanner;

class SumWithScanner
{
  public static void main(String[] ss)
  {
//create instance of Scanner
      Scanner sc=new Scanner(System.in);
       System.out.println("Enter 2 numbers to add"); 
     int num1=sc.nextInt();
	int num2=sc.nextInt();

     System.out.println("Sum="+(num1+num2));
  }
}
