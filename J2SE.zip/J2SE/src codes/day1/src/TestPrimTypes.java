class TestPrimTypes
{
 public static void main(String[] args)
 {
  // byte b1=128;
   byte b2=10;
   byte b3=45;
   byte b4=(byte)(b2+b3);
   b2 += 11; //b2 =(byte) (b2+11);
   long l1=1234567;
   float f=l1;
   f=123.45f;//RHS --double
    double d=b2;

	//char ---> int
    char ch='c';
    ch=123;
    int val=ch;
    short s=ch;

 } 
}
