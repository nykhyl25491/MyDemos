package thrds9;

public class Test3 {

	public static void main(String[] args) throws Exception {
		Utils u1 = new Utils();
		Utils u2 = new Utils();
		Thread t1 = new Thread(() -> {
			while (true)
				u1.test();
		}, "t1");
		Thread t2 = new Thread(() -> {
			while (true)
				u2.test();
		}, "t2");
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		System.out.println("main over....");

	}

}
