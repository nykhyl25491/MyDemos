package thrds8;

public class UpdateBalanceTask implements Runnable {
	private boolean exit;
	private Account a;
	public UpdateBalanceTask(Account a) {
		this.a = a;
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + " strted");
		try {
			while(!exit)
				a.updateBalance(500);
		} catch (Exception e) {
			System.out.println("err in " + Thread.currentThread().getName() + " " + e);
		}
		System.out.println(Thread.currentThread().getName() + " over");
	}
	
	public void quit()
	{
		exit=true;
	}
}
