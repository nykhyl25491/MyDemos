package thrds8;

public class CheckBalanceTask implements Runnable {
	private boolean exit;
	private Account a;
	public CheckBalanceTask(Account a) {
		this.a = a;
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + " strted");
		try {
			double bal=0;
			while(!exit) {
				bal=a.getBalance();
				if(bal != 10000)
				{
					System.out.println("ERROR!!!!!");
					System.exit(1);//terminating JVM
					
				}
			}
		} catch (Exception e) {
			System.out.println("err in " + Thread.currentThread().getName() + " " + e);
		}
		System.out.println(Thread.currentThread().getName() + " over");
	}
	
	public void quit()
	{
		exit=true;
	}
}
