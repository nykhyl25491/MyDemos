package thrds8;

public class Tester {

	public static void main(String[] args) throws Exception{
		//create a/c instance
		Account a1=new Account(10000);
		//Create thrds 
		UpdateBalanceTask task1=new UpdateBalanceTask(a1);
		CheckBalanceTask task2=new CheckBalanceTask(a1);
		Thread t1=new Thread(task1, "updater");
		Thread t2=new Thread(task2, "checker");
		t1.start();
		t2.start();
		//wait for a keystroke
		System.out.println("Press Enter to stop");
		System.in.read();//main thrd is blocked on i/p
		//stop the thrds
		task1.quit();
		task2.quit();
		//ensure no orphans
		t1.join();
		t2.join();
		System.out.println("main over.....");
		
		

	}

}
