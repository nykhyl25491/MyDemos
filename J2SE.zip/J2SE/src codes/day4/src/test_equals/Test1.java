package test_equals;

import com.app.core.Mgr;

public class Test1 {

	public static void main(String[] args) {
		Object m1=new Mgr(10,"a1", "a1@gmail", "rnd", 10000, 500);
		Object m2=new Mgr(10,"a1234", "a1@gmail", "rnd", 10000, 500);
		System.out.println(m1.equals(m2));
		/*String s="hello";
		System.out.println(m1.equals(s));
	*/
		

	}

}
