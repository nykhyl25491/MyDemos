package com.app.core;

public abstract class Emp {
	private int id;
	private String name, email, deptId;

	// constr
	public Emp(int id, String name, String email, String deptId) {
		this.name = name;
		this.email = email;
		this.deptId = deptId;
		this.id = id;
	}

	/*
	 * public Emp() {
	 * 
	 * }
	 */
	@Override
	public String toString() {
		return id + " " + name + " " + email + " " + deptId;
	}

	public String getName() {
		return name;
	}

	public String getDeptId() {
		return deptId;
	}

	// add abstract method
	public abstract double computeNetSalary();

	// equals by id
	@Override
	public boolean equals(Object o) {
		System.out.println("in emp equals");
		if (o instanceof Emp) {
//			return id == ((Emp) o).id;
			Emp e =(Emp)o;
			return id == e.id && email.equals(e.email);
		}
			
		return false;
	}

}
