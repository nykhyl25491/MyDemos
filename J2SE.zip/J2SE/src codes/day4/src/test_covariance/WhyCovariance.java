package test_covariance;

public class WhyCovariance {

	public static void main(String[] args) {
		B b1=new B();
		//invoke getInstance()
		B ref=b1.getInstance();
		//invoke show
		ref.show();
	}

}
class A {
	A getInstance() {
		System.out.println("1");
		return new A();
	}
}

class B extends A {
	B getInstance() {
		System.out.println("2");
		return new B();
	}
	void show()
	{
		System.out.println("in show");
	}
}
