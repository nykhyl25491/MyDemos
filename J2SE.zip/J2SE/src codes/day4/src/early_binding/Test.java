package early_binding;

public class Test {

	public static void main(String[] args) {
		A ref=new B();
		ref.test();//B' test --- D.M.D
		ref.show();//A's test --early binding
		System.out.println(ref.data);

	}

}
class A
 {
	int data=10;
	static void show()
	{
		System.out.println("in A's show");
	}
	void test()
	{
		System.out.println("in A's test");
	}
}
class B extends A
{
	int data=20;
//	@Override
	static void show()
	{
		System.out.println("in B's show");
	}
	@Override
	void test()
	{
		System.out.println("in B's test");
	}
}
