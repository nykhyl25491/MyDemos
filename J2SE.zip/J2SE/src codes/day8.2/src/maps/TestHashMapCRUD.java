package maps;

import java.util.*;
import com.app.core.Account;

import cust_excs.AccountHandlingException;

import static utils.CollectionUtils.*;
import static utils.ValidationRules.*;

public class TestHashMapCRUD {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			Map<Integer, Account> accts = populateMap();
			boolean exit = false;
			while (!exit) {
				try {
					System.out.println("1 : Create A/C \n 2 : Get A/C Summary \n  3 : Funds Transfer \n 4 : Close A/C "
							+ "\n 5 : Display all a/cs  \n 6 : Apply Interest \n" + "10 : Exit");
					System.out.println("Choose option");
					switch (sc.nextInt()) {
					case 1: // create new a/c
						System.out.println("Enter a/c info id nm type bal date");
						int id = sc.nextInt();
						Account a = accts.putIfAbsent(id,
								new Account(id, sc.next(), sc.next(), sc.nextDouble(), validateDate(sc.next())));
						// if dup id is detetec --throw cust exc.
						if (a != null)
							throw new AccountHandlingException("Dup Acct id!!!!!");
						break;
					case 2:
						System.out.println("Enter A/C ID");
						id = sc.nextInt();
						a = accts.get(id);// auto boxing
						if (a == null)
							throw new AccountHandlingException("Invalid A/C ID : No summary");
						System.out.println("Summary " + a);
						break;
					case 3:
						System.out.println("Enter src n dest A/C IDs n amount");
						id = sc.nextInt();
						a = accts.get(id);
						if (a == null)
							throw new AccountHandlingException("Invalid Src A/C ID : No Transfer");
						Account dest = accts.get(sc.nextInt());
						if (dest == null)
							throw new AccountHandlingException("Invalid Dest A/C ID : No Transfer");
						a.transferFunds(dest, sc.nextDouble());

						break;
					case 4:
						System.out.println("Enter a/c id for closing a/c");
						a = accts.remove(sc.nextInt());
						if (a == null)
							throw new AccountHandlingException("Invalid  A/C ID : No Closing A/C");
						System.out.println("A/C Closed : " + a);
						break;
					case 5:
						// display all a/cs info
						for (Account a2 : accts.values())
							System.out.println(a2);
						break;
					case 6 : //apply interest on all saving type of a/cs
						System.out.println("Enter interest rate");
						double rate=sc.nextDouble();
						for(Account a2 : accts.values())
							if(a2.getType().equals("saving"))
								a2.applyInterest(rate);
						break;

					case 10:
						exit = true;
						break;
					}
				} catch (Exception e) {
					System.out.println(e.getMessage());

				}
				// read off all pending i/ps from scanner's buffer
				sc.nextLine();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
