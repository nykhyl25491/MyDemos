package maps;

import static utils.CollectionUtils.*;

import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

import static java.util.Map.*;

import com.app.core.Account;

public class TestSortedMap {

	public static void main(String[] args) throws Exception {

		Map<Integer, Account> hm = populateMap();
		//sort the map as per asc order of acct ids.
		System.out.println("Accts sorted as per ids asc");
		TreeMap<Integer, Account> tm1=new TreeMap<>(hm);
		for(Account a : tm1.values())
			System.out.println(a);
		//sort the map as per desc acct ids
		TreeMap<Integer, Account> tm2=new TreeMap<>(new Comparator<Integer>() {

			@Override
			public int compare(Integer arg0, Integer arg1) {
				System.out.println("in compare ...");
				return arg1.compareTo(arg0);
			}
			
		});
		System.out.println(tm2);
		tm2.putAll(hm);
		System.out.println("desc oredered");
		for(Account a : tm2.values())
			System.out.println(a);
	
		
	}

}
