package maps;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class TestLinkedHashMap {

	public static void main(String[] args) {
		/*
		 * HashMap<Integer, String> hm = new HashMap<>(); hm.put(12, "a1");
		 * hm.put(1, "a2"); hm.put(10, "a3"); hm.put(120, "a4"); for(String s :
		 * hm.values()) System.out.print(s+" ");
		 */
		LinkedHashMap<Integer, String> hm = new LinkedHashMap<>();
		hm.put(12, "a1");
		hm.put(1, "a2");
		hm.put(10, "a3");
		hm.put(120, "a4");
		for (String s : hm.values())
			System.out.print(s + " ");

	}

}
