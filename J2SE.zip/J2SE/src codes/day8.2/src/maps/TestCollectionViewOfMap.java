package maps;

import static utils.CollectionUtils.*;

import java.util.Map;
import static java.util.Map.*;

import com.app.core.Account;

public class TestCollectionViewOfMap {

	public static void main(String[] args) throws Exception {

		Map<Integer, Account> hm = populateMap();
		// display only keys
		System.out.println("Keys : ");
		for (int k : hm.keySet())
			System.out.print(k + " ");
		System.out.println(hm.keySet().getClass().getName());
		System.out.println();
		// display only values
		System.out.println("Values : ");
		for (Account a : hm.values())
			System.out.println(a);
		System.out.println(hm.values().getClass().getName());
		// display both --Entry = mapping = key n val pair
		// java.util.Map.Entry<K,V>
		for (Entry<Integer, Account> e : hm.entrySet())
			System.out.println("Key : " + e.getKey() 
			+ " Value : " + e.getValue());
		System.out.println(hm.entrySet().getClass().getName());

	}

}
