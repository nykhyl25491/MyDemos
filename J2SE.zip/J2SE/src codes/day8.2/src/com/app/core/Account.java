package com.app.core;

import java.text.SimpleDateFormat;
import java.util.Date;



import cust_excs.AccountHandlingException;

import static utils.ValidationRules.*;

public class Account {
	private int acctId;
	private String name, type;
	private double balance;
	private Date creationDate;
	// SDF -- 1
	public static SimpleDateFormat sdf;

	static {
		sdf = new SimpleDateFormat("dd/MM/yyyy");
	}

	public Account(int acctId, String name, String type, double balance, Date creationDate) {
		super();
		this.acctId = acctId;
		this.name = name;
		this.type = type;
		this.balance = balance;
		this.creationDate = creationDate;
	}
	
	

	@Override
	public String toString() {
		return "A/C Summary id=" + acctId + ", name=" + name + ", type=" + type + ", balance=" + balance
				+ ", creationDate=" + sdf.format(creationDate);
	}

	// deposit
	public double deposit(double amt) {
		balance += amt;
		return balance;
	}

	// withdraw
	public double withdraw(double amt) throws AccountHandlingException{
		validateBalance(balance-amt);
		balance -= amt;
		return balance;
	}
	//transfer funds
	public void transferFunds(Account dest,double amt) throws AccountHandlingException
	{
		this.withdraw(amt);
		dest.deposit(amt);
	}
	
	public int getAcctId() {
		return acctId;
	}

	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}

	public double getBalance() {
		return balance;
	}

	public Date getCreationDate() {
		return creationDate;
	}
	public void applyInterest(double rate)
	{
		balance += (balance*rate/100);
	}
	
	
	

}
