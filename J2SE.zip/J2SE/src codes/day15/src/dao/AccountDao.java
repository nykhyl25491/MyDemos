package dao;

public interface AccountDao {
  String transferFunds(int sid,int destId,double amt) throws Exception;
}
