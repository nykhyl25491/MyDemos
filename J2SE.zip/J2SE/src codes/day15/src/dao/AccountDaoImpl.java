package dao;

import java.sql.*;
import static utils.DBUtils.*;

public class AccountDaoImpl implements AccountDao {
	private Connection cn;
	private CallableStatement cst1;

	public AccountDaoImpl() throws Exception {
		// cn
		cn = getConnection();
		cst1 = cn.prepareCall("{call update_account(?,?,?,?,?)}");
		// reg OUT params
		cst1.registerOutParameter(4, Types.DOUBLE);
		cst1.registerOutParameter(5, Types.DOUBLE);
		System.out.println("dao created....");
	}

	public void cleanUp() throws Exception {
		if (cst1 != null)
			cst1.close();
		if (cn != null)
			cn.close();
		System.out.println("dao clened up...");

	}

	@Override
	public String transferFunds(int sid, int destId, double amt) throws Exception {
		// set IN param
		cst1.setInt(1, sid);
		cst1.setInt(2, destId);
		cst1.setDouble(3, amt);
		// exec
		cst1.execute();
		return "Updated Src bal =" + cst1.getDouble(4) 
		+ " updated dest bal " + cst1.getDouble(5);
	}

}
