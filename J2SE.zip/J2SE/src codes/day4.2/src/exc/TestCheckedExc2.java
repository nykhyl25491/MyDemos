package exc;

import java.io.IOException;

public class TestCheckedExc2 {

	public static void main(String[] args) throws Exception{
		System.out.println("Before");
		
			Thread.sleep(1000);
			System.in.read();
		
		System.out.println("After");

	}

}
