package exc;

public class TestUnCheckedExc {

	public static void main(String[] args) {
		try {
		int a=100;
		int b=10;
		System.out.println("res="+(a/b));
		String[] ss={"aa","bb"};
		System.out.println(ss[1]);
		String s1=null;
		System.out.println(s1.charAt(0));
		s1="abc";
		System.out.println(Integer.parseInt(s1));
			System.out.println("end of try");
		} catch (ArithmeticException  | NullPointerException e) {
			System.out.println("1");
		} catch (ArrayIndexOutOfBoundsException e)
		{
			System.out.println("2");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("main over...");

	}

}
