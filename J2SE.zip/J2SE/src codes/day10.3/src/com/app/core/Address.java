package com.app.core;

import java.io.Serializable;

public class Address /*implements Serializable*/{
	private String city,state,country;
	private long phoneNo;
	public Address(String city, String state, String country, long phoneNo) {
		super();
		this.city = city;
		this.state = state;
		this.country = country;
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", country=" + country + ", phoneNo=" + phoneNo + "]";
	}
	
	
}
