package lambdas;

import static utils.CollectionUtils.*;

import java.util.HashMap;

import com.app.core.Emp;

public class Test1 {

	public static void main(String[] args) throws Exception {
		HashMap<Integer, Emp> emps = populateMap();
		emps.values().forEach(System.out::println);
		// OR --directly via forEach method of Map
		System.out.println("-------------------");
		emps.forEach((i, e) -> System.out.println("ID : " + i + " " + e));
		// paraller processing
		System.out.println("--------------------------");
		emps.entrySet().parallelStream().
		forEach(entry -> System.out.println(entry.getValue()));

	}

}
