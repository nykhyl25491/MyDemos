package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;

import com.app.core.Emp;

public class SerUtils {
	// store HM of emps on bin file using serialization
	public static void writeData(HashMap<Integer, Emp> emps, String fileName) throws Exception {
		try (ObjectOutputStream out = 
				new ObjectOutputStream
				(new FileOutputStream(fileName))) {
			out.writeObject(emps);
		}
	}

	// re store HM of emps from bin file using de serialization
	@SuppressWarnings("unchecked")
	public static HashMap<Integer,Emp> restoreInfo(String fileName) throws Exception
	{
		//validate
		File f1=new File(fileName);
		if(f1.exists() && f1.isFile() && f1.canRead())
		{
				try(ObjectInputStream in=
						new ObjectInputStream
						(new FileInputStream(f1)))
				{
					return (HashMap<Integer,Emp>)in.readObject();
				}
		}
		return null;
	}

}
