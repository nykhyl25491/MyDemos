package bin_io;

import java.util.Scanner;


import static utils.SerUtils.*;
public class RestoreEmpInfo {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in))
		{
			
			System.out.println("Enter file name to read data");
			restoreInfo(sc.nextLine()).values().forEach(e -> System.out.println(e));
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
