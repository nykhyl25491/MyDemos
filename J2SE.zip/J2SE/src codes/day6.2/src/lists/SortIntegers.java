package lists;

import java.util.ArrayList;
import java.util.Collections;

public class SortIntegers {

	public static void main(String[] args) {
		ArrayList<Integer> l1 = new ArrayList<>();
		// populate AL
		int[] data = { 10, 2, 3, 100, -10, 10, 2, 3, 2 };
		for (int i : data) // NONE
			l1.add(i);// auto boxing l1.add(new Integer(i));
		System.out.println("unsorted list"+l1);
		Collections.sort(l1);
		System.out.println("sorted list"+l1);
	
	}

}
