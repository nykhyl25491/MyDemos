package lists;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import static com.app.core.Account.sdf;
import static utils.CollectionUtils.*;

import com.app.core.Account;

import cust_excs.AccountHandlingException;

public class GetAccountSummary {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			List<Account> l1 = populateData();
			// display a/c info --for each
			for (Account a : l1)
				System.out.println(a);
			// l1.add(new Account(12, "abc2", "saving", 15000, new Date()));
			System.out.println("Enter a/c id");
			System.out.println
			(findByPrimaryKey(sc.nextInt(), l1));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
