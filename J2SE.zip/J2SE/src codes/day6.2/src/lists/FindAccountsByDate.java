package lists;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import static com.app.core.Account.sdf;
import static utils.CollectionUtils.*;
import static utils.ValidationRules.*;

import com.app.core.Account;

import cust_excs.AccountHandlingException;

public class FindAccountsByDate {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			List<Account> l1 = populateData();
			// display a/c info --for each
			for (Account a : l1)
				System.out.println(a);
			
			System.out.println("Enter date");
			//string -- date
			Date d1=validateDate(sc.next());
			for(Account a : l1)
				if(a.getCreationDate().after(d1))
					System.out.println(a.getName());
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
