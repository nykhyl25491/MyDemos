package lists;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import static com.app.core.Account.sdf;
import static utils.CollectionUtils.*;

import com.app.core.Account;

import cust_excs.AccountHandlingException;

public class TransferFunds {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			List<Account> l1 = populateData();
			// display a/c info --for each
			for (Account a : l1)
				System.out.println(a);
		
			System.out.println("Enter src a/c id , dest id n amount");
			Account src=findByPrimaryKey(sc.nextInt(), l1);
			Account dest=findByPrimaryKey(sc.nextInt(), l1);
			src.transferFunds(dest, sc.nextDouble());
			// display a/c info --for each
			for (Account a : l1)
				System.out.println(a);
		
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
