package tester;

import java.sql.*;
import static utils.DBUtils.*;

public class TestStatement {

	public static void main(String[] args) {
		// display emp details
		String sql = "select empid,name,salary,join_date from my_emp";
		try (Connection cn = getConnection();
				Statement st = cn.createStatement();
				ResultSet rst = st.executeQuery(sql);) {
			while (rst.next())
				System.out.printf("ID %d Name %s Salary %.1f Joined on %s %n", rst.getInt(1), rst.getString(2),
						rst.getDouble(3), rst.getDate(4));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
