package tester;

import java.sql.Date;
import java.util.Scanner;

import dao.EmpDaoImpl;

public class TestLayeredApplication {

	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in);) {
			// dao inst
			EmpDaoImpl dao = new EmpDaoImpl();
			System.out.println("Enter dept id n join date");
			dao.getEmpDetails(sc.next(), Date.valueOf(sc.next())).forEach(System.out::println);

			dao.cleanUp();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
