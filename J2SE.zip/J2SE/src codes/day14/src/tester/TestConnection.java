package tester;
import java.sql.*;
import static utils.DBUtils.*;

public class TestConnection {

	public static void main(String[] args) {
		try(Connection cn=getConnection())
		{
			System.out.println("connected to db "+cn);
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
