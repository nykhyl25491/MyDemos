package tester;

import java.sql.*;
import java.util.Scanner;

import static utils.DBUtils.*;

public class TestPST {

	public static void main(String[] args) {

		String sql = "select * from my_emp where deptid=? and join_date > ?";
		try (Scanner sc = new Scanner(System.in);
				Connection cn = getConnection();
				PreparedStatement pst = cn.prepareStatement(sql)) {
			System.out.println("Enter dept id n join date");
			//set IN params
			pst.setString(1, sc.next());
			pst.setDate(2, Date.valueOf(sc.next()));
			try(ResultSet rst=pst.executeQuery())
			{
				while(rst.next())
					System.out.printf("ID %d Name %s Salary %.1f Joined on %s %n", rst.getInt(1), rst.getString(2),
							rst.getDouble(4), rst.getDate(6));

			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
