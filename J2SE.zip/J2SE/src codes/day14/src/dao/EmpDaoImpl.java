package dao;

import java.sql.*;
import static utils.DBUtils.*;

import java.util.ArrayList;
import java.util.List;
import pojos.Employee;

public class EmpDaoImpl implements EmpDao {
	// D.M
	private Connection cn;
	private PreparedStatement pst1;

	public EmpDaoImpl() throws Exception {
		// get db conn
		cn = getConnection();
		// pst
		pst1 = cn.prepareStatement("select * from my_emp where deptid=? and join_date > ?");
		System.out.println("dao created....");
	}

	@Override
	public List<Employee> getEmpDetails(String dept, Date d1) throws Exception {
		// empty list
		ArrayList<Employee> l1 = new ArrayList<>();
		// set IN params
		pst1.setString(1, dept);
		pst1.setDate(2, d1);
		try (ResultSet rst = pst1.executeQuery()) {
			while (rst.next())
				l1.add(new Employee(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getDouble(4), dept,
						rst.getDate(6)));
		}

		return l1;
	}

	public void cleanUp() throws Exception {
		if (pst1 != null)
			pst1.close();
		if (cn != null)
			cn.close();
		System.out.println("dao cleaned up...");
	}

}
