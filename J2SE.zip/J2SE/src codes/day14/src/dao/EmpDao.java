package dao;

import java.sql.Date;
import java.util.List;

import pojos.Employee;

public interface EmpDao {
   List<Employee> getEmpDetails(String dept,Date d1) throws Exception;
}
