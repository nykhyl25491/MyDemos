package thrds3;

public class Tester {

	public static void main(String[] args) throws Exception {
		// display the details of the main thread
		System.out.println(Thread.currentThread());
		// create child thrds & test concurrency
		Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {
				System.out.println("running " + Thread.currentThread().getName());

			}
		}, "t1");
		Thread t2 = new Thread(() -> System.out.println("hello from " + Thread.currentThread().getName()), "t2");
		Thread t3 = new Thread(() -> System.out.println("hi...." + Thread.currentThread().getName()));
		t1.start();
		t2.start();
		t3.start();

		for (int i = 0; i < 2; i++) {
			System.out.println(Thread.currentThread().getName() + " exec # " + i);
			Thread.sleep(1000);
		}
		System.out.println("main over....");

	}

}
