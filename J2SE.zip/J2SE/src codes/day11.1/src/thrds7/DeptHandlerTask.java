package thrds7;

import java.util.ArrayList;

public class DeptHandlerTask implements Runnable {
	private IOUtils u;
	private ArrayList<Emp> list;

	public DeptHandlerTask(IOUtils u, ArrayList<Emp> list) {
		this.u = u;
		this.list = list;
	}

	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + " strted");
		try {
			u.writeData(list);
		} catch (Exception e) {
			System.out.println(Thread.currentThread().getName() + " " + e);
		}
		System.out.println(Thread.currentThread().getName() + " over");

	}

}
