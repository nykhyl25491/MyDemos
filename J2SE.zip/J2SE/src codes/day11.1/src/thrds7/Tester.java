package thrds7;

import static thrds7.CollectionUtils.*;

import java.util.ArrayList;

public class Tester {

	public static void main(String[] args) {
		try {
			// create Utils cls instance to create data files
			IOUtils u1 = new IOUtils("rnd.data");
			IOUtils u2 = new IOUtils("sales.data");
			IOUtils u3 = new IOUtils("prod.data");
			// get populated data & pass the same to D.H tasks
			ArrayList<ArrayList<Emp>> lists = populateData();
			// thrds
			Thread t1 = new Thread(new DeptHandlerTask(u1, lists.get(0)), "t1");
			Thread t2 = new Thread(new DeptHandlerTask(u2, lists.get(1)), "t2");
			Thread t3 = new Thread(new DeptHandlerTask(u3, lists.get(2)), "t3");
			//start
			t1.start();
			t2.start();
			t3.start();
			System.out.println("main waiting for child thrds to finish exexc");
			t1.join();
			t2.join();
			t3.join();
			u1.cleanUp();
			u2.cleanUp();
			u3.cleanUp();
			System.out.println("main over....");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
