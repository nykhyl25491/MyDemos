package thrds7;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;

public class IOUtils {
	private PrintWriter pw;
	private Random r;

	public IOUtils(String fileName) throws Exception {
		pw = new PrintWriter(new FileWriter(fileName));
		r = new Random();
	}

	public void cleanUp() {
		if (pw != null)
			pw.close();

	}

	public void writeData(ArrayList<Emp> deptList) {
		deptList.forEach(e -> {
			try {
				pw.println(e);
				Thread.sleep(r.nextInt(100) + 1);
			} catch (Exception e1) {
				System.out.println("Err in thrd " + Thread.currentThread().getName() + " " + e1);
			}
		});
	}

}
