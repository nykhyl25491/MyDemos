package thrds7;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CollectionUtils {
	public static ArrayList<ArrayList<Emp>> populateData() {
		ArrayList<ArrayList<Emp>> l1 = new ArrayList<>();
		String dept = "rnd";
		ArrayList<Emp> rndList = new ArrayList<>();
		for (int i = 1; i <= 5; i++)
			rndList.add(new Emp(i, "a" + i, dept, 1000 * i));
		dept = "sales";
		ArrayList<Emp> salesList = new ArrayList<>();
		for (int i = 6; i <= 10; i++)
			salesList.add(new Emp(i, "a" + i, dept, 1000 * i));
		dept = "prod";
		ArrayList<Emp> prodList = new ArrayList<>();
		for (int i = 11; i <= 15; i++)
			prodList.add(new Emp(i, "a" + i, dept, 1000 * i));
		l1.add(rndList);
		l1.add(salesList);
		l1.add(prodList);
		System.out.println(l1);
		return l1;

	}

}
