package thrds7;



public class Emp  {
	private int id;
	private String name,deptId;
	private double salary;
	

	public Emp(int id, String name, String dept,double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		deptId=dept;
	}


	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + ", deptId=" + deptId + ", salary=" + salary + "]";
	}
	

	
	
}
