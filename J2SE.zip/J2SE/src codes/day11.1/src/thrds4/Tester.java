package thrds4;

public class Tester {

	public static void main(String[] args) throws Exception {
		// display the details of the main thread
		System.out.println(Thread.currentThread());
		// create child thrds & test concurrency
		Thread t1 = new Thread(new MyRunnableTask(), "t1");
		Thread t2 = new Thread(new MyRunnableTask(), "t2");
		Thread t3 = new Thread(new MyRunnableTask());
		t1.start();
		t2.start();
		t3.start();

		for (int i = 0; i < 10; i++) {
			System.out.println(Thread.currentThread().getName() + " exec # " + i);
			Thread.sleep(100);
		}
		System.out.println("main waiting for child thrds to finish exec");
		//join
		t1.join();
		t2.join();
		t3.join();
		System.out.println("main over....");

	}

}
