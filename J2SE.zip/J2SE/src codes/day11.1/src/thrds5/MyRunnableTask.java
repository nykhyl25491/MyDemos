package thrds5;

public class MyRunnableTask implements Runnable {

	/*
	 * Overriding form of the method can't include in thr throws clause NEW
	 * checked exc
	 */
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + " strted");
		try {
			int i = 0;
			while (true) {
				System.out.println(Thread.currentThread().getName() + " exec # " + (i++));
				Thread.sleep(500);
			}
		} catch (Exception e) {
			System.out.println(Thread.currentThread().getName() + " thrd err " + e);
		}
		System.out.println(Thread.currentThread().getName() + " over");
	}
}
