package thrds5;

public class Tester {

	public static void main(String[] args) throws Exception {
		// display the details of the main thread
		System.out.println(Thread.currentThread());
		// create child thrds & test concurrency
		Thread t1 = new Thread(new MyRunnableTask(), "t1");
		Thread t2 = new Thread(new MyRunnableTask(), "t2");
		Thread t3 = new Thread(new MyRunnableTask(), "t3");
		t1.start();
		t2.start();
		t3.start();

		
		System.out.println("main waiting for child thrds for some time to finish exec");
		// join
		t1.join(1000);
		t2.join(2000);
		t3.join(3000);
		System.out.println("main interrupting child thrds..." + t1.isAlive());
		t1.interrupt();
		t2.interrupt();
		t3.interrupt();
		System.out.println("waiting again ...");
		t1.join();
		t2.join();
		t3.join();
		System.out.println(t1.isAlive() + " " + t2.isAlive() + " " + t3.isAlive());
		System.out.println("main over....");

	}

}
