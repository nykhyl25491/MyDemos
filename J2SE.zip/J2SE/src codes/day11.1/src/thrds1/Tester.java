package thrds1;

public class Tester {

	public static void main(String[] args) throws Exception{
		//display the details of the main thread
		System.out.println(Thread.currentThread());
		//create child thrds & test concurrency
		MyThread t1=new MyThread("one");
		MyThread t2=new MyThread("two");
		MyThread t3=new MyThread("three");
		for (int i = 0; i < 10; i++) {
			System.out.println(Thread.currentThread().getName() + " exec # " + i);
			Thread.sleep(1000);
		}
		System.out.println("main over....");

	}

}
