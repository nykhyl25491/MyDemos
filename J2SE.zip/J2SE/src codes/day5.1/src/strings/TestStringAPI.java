package strings;

import java.util.Arrays;

public class TestStringAPI {

	public static void main(String[] args) {
		// create string from bytes
		byte[] bytes={65,66,67,68,69,70};
		System.out.println(new String(bytes));
		System.out.println(new String(bytes,2,4));
		//create string from chars
		char[] chars={'a','b','c','d'};
		System.out.println(new String(chars,1,3));
		//get char at specific position
		System.out.println("hello".charAt("hello".length()-1));
		//comparing strings (typically for sorting purpose)
		String s1="adsgdsg1";
		String s2=s1.toUpperCase();
		System.out.println(s1.compareTo(s2));
		String[] names={"abc","ABC","12345","abdg","xvxcv"};
		Arrays.sort(names);
		System.out.println(Arrays.toString(names));
		
		//searching 
		s1="Java strings are easy , strings api is easier";
		System.out.println(s1.indexOf("strings")
				+" "+s1.lastIndexOf("strings"));
		//matching reg expression
		String pattern="[a-z]*[0-9]*[@,$,#,*,%]";
		System.out.println("abc$123".matches(pattern));
		System.out.println("abc123#".matches(pattern));
		//splitting strings
		s1="abc:def:454:68678";
		System.out.println(Arrays.toString(s1.split(":")));
		

	}

}
