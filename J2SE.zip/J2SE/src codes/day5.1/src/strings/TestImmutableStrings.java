package strings;

public class TestImmutableStrings {

	public static void main(String[] args) {
		 String s="hello";
		s=s.concat("hi");
		 s += "1234";//s = s +"1234";
		//System.out.println(s1);
		System.out.println(s);
		s.toUpperCase();
		System.out.println(s);

	}

}
