package tester;

import java.util.Scanner;

import com.app.core.Emp;
import com.app.core.Mgr;
import com.app.core.Worker;
import static utils.ValidationRules.*;

public class TestOrg3 {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {

			System.out.println("Enter Org size");
			Emp[] emps = new Emp[sc.nextInt()];
			emps[0] = new Mgr("a1", "a1@gmail", "rnd", 10000, 500);
			emps[1] = new Worker("a2", "a2@gmail", "prod", 25, 50);
			int counter = 2;
			boolean exit = false;
			while (!exit) {
				try {
					System.out.println("1 : Hire Mgr \n 2: Hire Worker \n " + "3: Display Org Details \n "
							+ "4 : Display Specific Emp Info \n " + "5 : Display Specific Emp's job details \n "
							+ "10 :Exit)");
					System.out.println("Choose Option");
					switch (sc.nextInt()) {
					case 1: // hire mgr
						if (counter < emps.length) {
							System.out.println("Enter mgr dtls nm em dept basic bonus");
							String name = sc.next();
							validateName(name);
							String em=sc.next();
							validateEmail(em);
							String dept=sc.next();
							validateDept(dept);
							double basic=sc.nextDouble();
							validateBasic(basic);
							emps[counter++] = new Mgr(name, em, dept,basic,sc.nextDouble());
						} else
							System.out.println("Recruitment over....");

						break;
					case 2:
						// hire worker
						if (counter < emps.length) {
							System.out.println("Enter worker dtls nm em dept hrs rate");
							emps[counter++] = new Worker(sc.next(), sc.next(), sc.next(), sc.nextInt(),
									sc.nextDouble());
						} else
							System.out.println("Recruitment over....");

						break;
					case 3: // display org details --for each
						for (Emp e : emps) // e=emps[0].....e=emps[emps.length-1]
							if (e != null)
								System.out.println(e + " Net sal =" + e.computeNetSalary());// D.M.D

						break;
					case 4: // specific emp info
						System.out.println("Enter emp id");
						int index = sc.nextInt() - 100;
						if (index >= 0 && index < counter)
							System.out.println(emps[index]);
						else
							System.out.println("Invalid emp id!!!!!");

						break;
					case 5: // display job details
						System.out.println("Enter emp id");
						index = sc.nextInt() - 100;
						if (index >= 0 && index < counter) {
							Emp e = emps[index];
							// un comment to understand issue if (e instanceof
							// Emp)
							if (e instanceof Mgr)
								((Mgr) e).manageEmps();
							else
								((Worker) e).workDetails();
						} else
							System.out.println("Invalid emp id!!!!!");
						break;

					case 10:
						exit = true;
						break;
					}
				} catch (Exception e) {
					//e.printStackTrace();
					System.out.println(e);
				}
				// read off pending i/ps from scanner
				sc.nextLine();
			}

		}

	}

}
