package utils;

import cust_excs.EmpHandlingException;

public class ValidationRules {
	public static final int MIN_LENGTH;
	public static final int MAX_LENGTH;
	public static final double MIN_BASIC;
	static {
		MIN_LENGTH = 4;
		MAX_LENGTH = 10;
		MIN_BASIC=5000;
	}

	public static void validateName(String name) throws EmpHandlingException {
		if (name.length() < MIN_LENGTH || name.length() > MAX_LENGTH)
			throw new EmpHandlingException("Invalid emp name");
		System.out.println("valid name");
	}

	public static void validateEmail(String email) throws Exception {
		if (email.length() < MIN_LENGTH || email.length() > MAX_LENGTH || !email.contains("@"))
			throw new EmpHandlingException("Invalid Email.....");
	}

	public static void validateDept(String dept) throws Exception {
		switch (dept) {
		case "rnd":
		case "hr":
		case "prod":
			break;

		default:
			throw new EmpHandlingException("Invalid dept id");

		}
	}
	public static void validateBasic(double basic) throws Exception
	{
		if(basic < MIN_BASIC)
			throw new EmpHandlingException("Invalid basic!!!!");
		
	}

}
