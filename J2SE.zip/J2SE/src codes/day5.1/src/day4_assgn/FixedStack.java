package day4_assgn;

public class FixedStack implements Stack{
	private Emp[] emps;
	private int top;
	public FixedStack() {
		emps=new Emp[SIZE];
		top=-1;
	}
	@Override
	public void push(Emp e)
	{
		if(top < emps.length-1)
			emps[++top]=e;
		else
			System.out.println("Stack overflow");
	}
	@Override
	public Emp pop()
	{
		if(top == -1) 
			return null;
		return emps[top--];
	}
	

}
