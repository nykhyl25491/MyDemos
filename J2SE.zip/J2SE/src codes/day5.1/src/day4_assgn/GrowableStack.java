package day4_assgn;

public class GrowableStack implements Stack{
	private Emp[] emps;
	private int top;
	public GrowableStack() {
		emps=new Emp[SIZE];
		top=-1;
	}
	@Override
	public void push(Emp e)
	{
		if(top < emps.length-1)
			emps[++top]=e;
		else {
			//create new array -- with size twice of orig
			Emp[] tmp=new Emp[emps.length*2];
			// array copy
			for(int i=0;i<emps.length;i++)
				tmp[i]=emps[i];
			//re assign old array ref to new array
			emps=tmp;
			emps[++top]=e;
	
		}
			
	}
	@Override
	public Emp pop()
	{
		if(top == -1)
			return null;
		return emps[top--];
	}
	

}
