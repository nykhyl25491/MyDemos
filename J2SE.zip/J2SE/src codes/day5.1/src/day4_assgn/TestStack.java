package day4_assgn;

import java.util.Scanner;

public class TestStack {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean exit = false;
		// i/f ref
		Stack ref = null;
		while (!exit) {
			System.out
					.println("1 : Fixed Stack 2 : Growable Stack \n 3: Store Emp Data 4: Restore Emp Data \n 5: Exit");
			System.out.println("Choose Option");
			switch (sc.nextInt()) {
			case 1: // FS
				if (ref == null)
					ref = new FixedStack();
				else
					System.out.println("U have alrdy chosen a stack!!!!");

				break;
			case 2: // GS
				if (ref == null)
					ref = new GrowableStack();
				else
					System.out.println("U have alrdy chosen a stack!!!!");

				break;
			case 3: // push
				if (ref != null) {
					System.out.println("Enter emp info : id name");
					Emp e1 = new Emp(sc.nextInt(), sc.next());
					ref.push(e1); // D.M. D -- by the type of obj
				} else
					System.out.println("You have not yet chosen a stack!!!!");
				break;
			case 4: // pop
				if (ref != null) {
					Emp e1=ref.pop();
					System.out.println(e1 == null ? "Stack Underflow " : e1);
				} else
					System.out.println("You have not yet chosen a stack!!!!");

				break;

			case 5:
				exit = true;
				break;
			}

		}
		if (sc != null)
			sc.close();

	}

}
