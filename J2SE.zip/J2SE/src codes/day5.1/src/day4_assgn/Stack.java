package day4_assgn;

public interface Stack {
	//D.M
	int SIZE=3;
	void push(Emp e);
	Emp pop();

}
