package bin_io;

import java.util.Scanner;

import com.app.core.Emp;
import static utils.SerUtils.*;
import static utils.CollectionUtils.*;
public class SaveEmpInfo {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in))
		{
			System.out.println("Enter file name");
			writeData(populateMap(),sc.nextLine());
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
