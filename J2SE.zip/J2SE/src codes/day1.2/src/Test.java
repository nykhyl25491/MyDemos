class Test
{
  public static void main(String[] args)
  {
    int data;
   data=123;
    System.out.print(data);
  }
}
