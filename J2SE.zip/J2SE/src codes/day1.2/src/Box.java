class Box
{
  //instance vars --state 
  private double width,depth,height;
   //constr
  Box(double w,double d,double height)
  {
    width=w;
    depth=d;
    //this --- to un hide instance var from method local var.
    this.height=height;
  }
  //void ret method to display Box dims
  void displayDims()
  {
    System.out.println("Box Dims "+width+" "+depth+" "+height);
  }
 // method to ret volume to the caller
  double calcVolume()
  {
     return width*depth*height;
  }
  
}
