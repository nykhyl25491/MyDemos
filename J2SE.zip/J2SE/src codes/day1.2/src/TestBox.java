import java.util.Scanner;

class TestBox 
{
  public static void main(String[] args)
  {
    //sc
    Scanner sc=new Scanner(System.in);
    //prompt
     System.out.println("Enter Box Dims");
     Box b1;
	//System.out.println(b1);//javac err
     b1=new Box(sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
     //display
     b1.displayDims();
     System.out.println("Volume = "+b1.calcVolume());
     Box b2=new Box(2,3,4);
      b2.displayDims();
     System.out.println("Volume = "+b2.calcVolume());
  
     
  }
}
