

class TestBox2 
{
  public static void main(String[] args)
  {
 	
       Box b2=new Box(2,3,4);
      b2.displayDims();
     System.out.println("Volume = "+b2.calcVolume());
      Box b1=b2;
      b1.displayDims();
     System.out.println("Volume = "+b1.calcVolume());
     System.out.println(b1==b2);
     System.out.println(b1);
     System.out.println(b2);
     b1=null;
   //  b1.displayDims();
 b2.displayDims();
    b2=null;
  //  b2.displayDims();
   
  
     
  }
}
