package p5;

public interface B extends A{
	void show();
}
