package p6;

public class Tester {

	public static void main(String[] args) {
		//direct ref
		Circle c1=new Circle(10, 20, 10.5);
		System.out.println(c1 +" area ="+c1.computeArea()
		+" peri "+c1.computePerimeter());
		Rectangle r1=new Rectangle(30, 10, 12, 5);
		System.out.println(r1 +" area ="+r1.computeArea()
		+" peri "+r1.computePerimeter());
		Computable[] refs={c1,r1};
		for(Computable ref : refs)
			System.out.println(ref.computeArea()+" "+ref.computePerimeter());
	

	}

}
