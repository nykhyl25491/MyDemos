package p6;

public interface Computable {
	//D.M
	double PI=3.1414;
	//methods
	double computeArea();
	double computePerimeter();

}
