package p6;

public  class Circle extends Point2D implements Computable {
	private double radius;

	public Circle(int x, int y, double rad) {
		super(x,y);
		radius=rad;
	}
	@Override
	public String toString()
	{
		return "Circle "+super.toString()+" rad="+radius;
	}
	@Override
	public double computeArea()
	{
		return PI*radius*radius;
	}
	@Override
	public double computePerimeter()
	{
		return 2*PI*radius;
	}
}
