package p2;

public interface Sortable {
	void sort();
	

}
