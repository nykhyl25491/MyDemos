package p2;

public class Tester {

	public static void main(String[] args) {
		MyImpleClass m1=new MyImpleClass();
		m1.print();
		m1.sort();

	}

}
