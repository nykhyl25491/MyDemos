package p1;

public interface Printable {
	//D.M  --- public static final
	double SIZE=10;
	//methods --- public abstract
	void print();

}
