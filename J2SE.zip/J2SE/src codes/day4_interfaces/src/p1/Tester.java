package p1;
//import static p1.Printable.*;

public class Tester {

	public static void main(String[] args) {
		MyPrintable m1=new MyPrintable();
		m1.print();
		System.out.println(Printable.SIZE);

	}

}
