package p1;

public class MyPrintable implements Printable {
	@Override
	public void print()
	{
		//imple class can directly acces i/f constants.
		System.out.println("in my print "+SIZE);
	}

}
