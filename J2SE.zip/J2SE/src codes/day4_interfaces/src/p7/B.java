package p7;

public interface B {
	void show();
}
