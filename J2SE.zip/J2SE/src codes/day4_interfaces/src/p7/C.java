package p7;

public class C implements B1{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double calc(double d1, double d2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void test() {
		// TODO Auto-generated method stub
		
	}

	

}
