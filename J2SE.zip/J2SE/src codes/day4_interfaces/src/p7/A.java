package p7;

public interface A {
	double calc(double d1,double d2);
	

}
