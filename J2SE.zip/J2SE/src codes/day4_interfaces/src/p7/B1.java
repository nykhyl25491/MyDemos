package p7;

public interface B1 extends A, B {
  void test();
}
