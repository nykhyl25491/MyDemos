package p4;

public interface Sortable {
	//D.M  --- public static final
		double SIZE=100;
	//methods --- public abstract
		void print();
	

}
