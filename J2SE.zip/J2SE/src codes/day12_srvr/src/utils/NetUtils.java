package utils;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import static utils.CollectionUtils.*;

import com.app.core.User;

public class NetUtils {
	public static void service(HashMap<String, User> hm, ObjectInputStream in, ObjectOutputStream out)
			throws Exception {
		// read cmd received from clnt
		switch (in.readUTF()) {
		case "login":
			System.out.println("in login ");
			// read em n password.
			out.writeObject(authenticate(hm, in.readUTF(),
					in.readUTF()));
			out.flush();
			break;
		default:
			System.out.println("invalid command!!!!");
			out.writeObject(null);
			out.flush();
			break;
		}

	}

}
