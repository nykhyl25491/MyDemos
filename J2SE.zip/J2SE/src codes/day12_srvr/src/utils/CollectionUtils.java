package utils;

import java.util.HashMap;

import com.app.core.User;

public class CollectionUtils {
	public static HashMap<String, User> populateMap() {
		HashMap<String, User> users = new HashMap<>();
		users.put("a@gmail", new User("a@gmail", "1234", 500));
		users.put("b@gmail", new User("b@gmail", "5234", 1500));
		return users;
	}

	public static User authenticate(HashMap<String, User> hm, String em, String pass) throws Exception {
		User u = hm.get(em);
		if (u != null)
			if (u.getPassword().equals(pass))
				return u;
		return null;
	}

}
