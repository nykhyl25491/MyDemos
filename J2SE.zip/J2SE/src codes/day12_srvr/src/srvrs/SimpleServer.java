package srvrs;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class SimpleServer {
	public static final int SERVER_PORT = 5000;

	public static void main(String[] args) {
		System.out.println("waiting for clnt connection");
		try (ServerSocket ss = new ServerSocket(SERVER_PORT, 1); 
				Socket ds = ss.accept();) {
			System.out.println(
					"Accepted cn from Clnt IP " + ds.getInetAddress().getHostAddress() + " clnt port " + ds.getPort());
			// attach suitable data strms & data transfer
			DataOutputStream out = new DataOutputStream(ds.getOutputStream());
			DataInputStream in = new DataInputStream(ds.getInputStream());
			// read request n send resp
			System.out.println("Clnt sent : " + in.readUTF());
			out.writeUTF("I m good , Bye.....");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("server application terminated....");

	}

}
