package srvrs;

import java.io.EOFException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

import com.app.core.User;

import static utils.NetUtils.*;
import static utils.CollectionUtils.*;

public class UserManagementServer {
	public static final int SERVER_PORT = 4500;

	public static void main(String[] args) {
		HashMap<String, User> users = populateMap();
		try (ServerSocket ss = new ServerSocket(SERVER_PORT, 1);
				// DS
				Socket ds = ss.accept();)

		{
			System.out.println("Accepted cn from clnt...");
			// attach suitable data strms
			ObjectOutputStream out = new ObjectOutputStream(ds.getOutputStream());
			out.flush();// to flush out ser header explicitely to clnt.
			ObjectInputStream in = new ObjectInputStream(ds.getInputStream());
			// keep on servicing the clnt --
			// till clnt application terminates
			try {
				while (true)
					service(users, in, out);
			} catch (EOFException e) {
				System.out.println("err in server " + e);
				System.out.println("clnt terminated...shutting down server!!!!");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
