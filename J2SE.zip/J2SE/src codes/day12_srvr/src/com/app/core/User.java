package com.app.core;

import java.io.Serializable;

public class User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String email,password;
	private double regAmount;
	public User(String email, String password, double regAmount) {
		super();
		this.email = email;
		this.password = password;
		this.regAmount = regAmount;
	}
	@Override
	public String toString() {
		return "User [email=" + email + ", password=" + password + ", regAmount=" + regAmount + "]";
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getEmail() {
		return email;
	}
	public String getPassword() {
		return password;
	}
	public double getRegAmount() {
		return regAmount;
	}
	
	
	

}
