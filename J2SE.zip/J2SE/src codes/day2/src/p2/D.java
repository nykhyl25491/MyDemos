package p2;
import p1.A;
class D extends A
{
  
  D()
  {
     System.out.println("B's state "+i+" "+j+" "+k+" "+l);
  }
}
