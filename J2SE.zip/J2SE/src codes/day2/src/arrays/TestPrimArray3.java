package arrays;
//import all static members for Arrays class
import java.util.Arrays;//helper class for array manipulations


class TestPrimArray3
{
   public static void main(String[] args)
   {
      //dynamic init of array
      int[] ints={2,45,67,123};
   	//display array contents using Arrays API
   	System.out.println("Via toString "+Arrays.toString(ints));
       ints=new int[] {4,8,16};
       System.out.println("Via toString "+Arrays.toString(ints));


   }
}
