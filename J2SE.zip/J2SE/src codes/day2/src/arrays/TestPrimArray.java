package arrays;
import java.util.Scanner;

class TestPrimArray
{
   public static void main(String[] args)
   {
     //sc
     Scanner sc=new Scanner(System.in);
     //accept array size
     System.out.println("Enter array size");
     //array
     double[] data;
     data=new double[sc.nextInt()];
     //print name of the loaded class
     System.out.println("Loaded array clas "+data.getClass().getName());
     //print array data
     for(int i=0;i<data.length;i++)
       System.out.print(data[i]+" ");
	System.out.println();
     //populate array
     for(int i=0;i<data.length;i++) {
       System.out.print("Enter array data");
        data[i]=sc.nextDouble();
     }
	//print array data
     for(int i=0;i<data.length;i++)
       System.out.print(data[i]+" ");
	System.out.println();
      //dynamic init of array
      int[] ints={2,45,67,123};
       System.out.println("Loaded array class "+ints.getClass().getName());
      //print array contents using for-each
      for(int a : ints)//a=ints[0],.....a=ints[ints.length-1]
       System.out.print(a+" ");
      System.out.println();
   


   }
}
