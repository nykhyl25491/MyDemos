package arrays;
import java.util.Arrays;//helper class for array manipulations


class TestPrimArray2
{
   public static void main(String[] args)
   {
      //dynamic init of array
      int[] ints={2,45,67,123};
       System.out.println("Loaded array class "+ints.getClass().getName());
      //print array contents using for-each
      for(int a : ints)//a=ints[0],.....a=ints[ints.length-1] 
	{
 	a *= 2;
       System.out.print(a+" ");
        }
      System.out.println();
	for(int a : ints)//a=ints[0],.....a=ints[ints.length-1] 
	{
 	
       System.out.print(a+" ");
        }
	System.out.println();
	//display array contents using Arrays API
   	System.out.println("Via toString "+Arrays.toString(ints));


   }
}
