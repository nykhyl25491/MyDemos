package arrays;
import java.util.*;
import com.sunbeam.core.*;

class TestRefArray
{
   public static void main(String[] args)
   {
    //sc
     Scanner sc=new Scanner(System.in);
    // prompt user for no of boxes
    System.out.println("Enter how many boxes to make");
    Box[] boxes=new Box[sc.nextInt()];
    System.out.println("Loaded class "+boxes.getClass().getName());
    //for -each
    for(Box b : boxes) //b=boxes[0],.....b=boxes[boxes.length-1]
     System.out.println(b);
     //populate array
     for(int i=0;i<boxes.length;i++)
    {
      System.out.println("Enter Box dims ");
      boxes[i]=new Box(sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
    }
    //for-each
     for(Box b : boxes)
      b.displayDims();
    //Arrays toString
    System.out.println("Via toString "+Arrays.toString(boxes));
   }
}
