package com.sunbeam.tester;
import java.util.Scanner;
import com.sunbeam.core.Box;
import com.sunbeam.utils.*;

class TestBox
{
  public static void main(String[] args)
  {
    //sc
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter 1st cube dim");
    Box b1=new Box(sc.nextDouble());
    b1.displayDims();
    System.out.println("Enter 2nd cube dim");
    Box b22=new Box(sc.nextDouble());
    b22.displayDims();
    System.out.println(BoxUtils.testEquals(b1,b22) ? "SAME" : "DIFFERENT");
    
  }
}
