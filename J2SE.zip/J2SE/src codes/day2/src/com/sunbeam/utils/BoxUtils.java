package com.sunbeam.utils;
import com.sunbeam.core.Box;
public class BoxUtils
{
  //add static method to chk equality of 2 boxes -- as per dims
  public static boolean testEquals(Box b1,Box b2)
  {
   return (b1.getWidth() == b2.getWidth()) && (b1.getDepth() == b2.getDepth()) && (b1.getHeight() == b2.getHeight());
  }
}
