package com.app.core;

public class Mgr extends Emp{
	private double basic,perfBonus;
	public Mgr(String name,String email,String dept,double basic,double bonus)
	{
		//explicitely invoking MATCHING immediate super cls constr
		super(name,email,dept);
		this.basic=basic;
		perfBonus=bonus;
				
	}
	@Override
	public String toString()
	{
	  return "Mgr "+super.toString()+basic+" "+perfBonus;
	}
	//additional behaviour
	public void manageEmps()
	{
		System.out.println(getName()+" managing "+getDeptId());
	}
	@Override
	public  double computeNetSalary()
	{
		return basic+perfBonus;
				
	}
	
}
