package test_equals;

import com.app.core.Mgr;

public class Test1 {

	public static void main(String[] args) {
		Mgr m1=new Mgr("a1", "a1@gmail", "rnd", 10000, 500);
		Mgr m2=new Mgr("a1", "a1@gmail", "rnd", 10000, 500);
		Mgr m3=m1;
		System.out.println(m1==m2);
		System.out.println(m1==m3);
		System.out.println(m1.equals(m2));
		System.out.println(m1.equals(m3));
		System.out.println(m1.hashCode());
		System.out.println(m2.hashCode());
		System.out.println(m3.hashCode());
		
		

	}

}
