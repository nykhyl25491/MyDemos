package thrds10;

public class Test4 {

	public static void main(String[] args) throws Exception {
		Utils u1 = new Utils();
		Thread t1 = new Thread(() -> {
			try {
				while (true) {
					u1.test();
					Thread.sleep(20);
				}
			} catch (Exception e) {
				System.out.println("err in t1 " + e);
			}
		}, "t1");
		Thread t2 = new Thread(() -> {
			try {
				while (true) {
					synchronized (u1) {
						u1.testMeAgain();
					}
					Thread.sleep(35);
				}
			} catch (Exception e) {
				System.out.println("err in t2 " + e);
			}

		}, "t2");
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		System.out.println("main over....");

	}

}
