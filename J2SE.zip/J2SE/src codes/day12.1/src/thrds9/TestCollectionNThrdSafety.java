package thrds9;

import java.util.HashMap;

public class TestCollectionNThrdSafety {

	public static void main(String[] args) throws Exception {
		HashMap<Integer, String> hm = new HashMap<>();
		Thread t1 = new Thread(() -> {
			try {
				int i = 1;
				while (true) {
					synchronized (hm) {
						hm.put(i++, "test" + i);
					}
					Thread.sleep(20);

					if (i > 1000) {
						i = 1;
						synchronized (hm) {
							hm.clear();
						}

					}
				}
			} catch (Exception e) {
				System.out.println("err in t1 " + e);
			}
		}, "t1");
		Thread t2 = new Thread(() -> {
			try {
				while (true) {
					synchronized (hm) {
						for (String s : hm.values())
							System.out.println(s);

					}
					Thread.sleep(35);
				}
			} catch (Exception e) {
				System.out.println("err in t2 " + e);
			}

		}, "t2");
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		System.out.println("main over....");

	}

}
