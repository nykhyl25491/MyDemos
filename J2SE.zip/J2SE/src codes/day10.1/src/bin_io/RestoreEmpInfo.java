package bin_io;

import java.util.Scanner;

import com.app.core.Emp;
import static utils.BinIOUtils.*;
public class RestoreEmpInfo {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in))
		{
			
			System.out.println("Enter file name to read data");
			Emp e=readData(sc.nextLine());
			System.out.println("data restored..."+e);
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
