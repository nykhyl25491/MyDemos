package bin_io;

import java.util.Scanner;

import com.app.core.Emp;
import static utils.BinIOUtils.*;
public class SaveEmpInfo {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in))
		{
			System.out.println("Enter emp data : id name sal");
			Emp e=new Emp(sc.nextInt(),sc.next(),sc.nextDouble());
			sc.nextLine();
			System.out.println("Enter file name");
			storeData(e, sc.nextLine());
			System.out.println("data stored....");
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
