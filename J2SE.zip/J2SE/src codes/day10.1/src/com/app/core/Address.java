package com.app.core;

public class Address {
	private String city,state,country;
	private long phoneNo;
	public Address(String city, String state, String country, long phoneNo) {
		super();
		this.city = city;
		this.state = state;
		this.country = country;
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", country=" + country + ", phoneNo=" + phoneNo + "]";
	}
	
	
}
