package utils;

import java.util.*;

import com.app.core.Address;
import com.app.core.Emp;

public class CollectionUtils {
	// rets AL<Emp>
	public static List<Emp> populateData() {
		ArrayList<Emp> l1 = new ArrayList<>();
		Collections.addAll(l1, new Emp(1, "abc", 1000), new Emp(23, "abc2", 5000), new Emp(11, "abc3", 11000),
				new Emp(16, "abc4", 6000));
		return l1;
	}

	public static HashMap<Integer, Emp> populateMap() throws Exception {
		Emp[] emps = { new Emp(1, "abc1", 1000), new Emp(10, "abc2", 10000), new Emp(5, "abc3", 5000),
				new Emp(20, "abc4", 20000) };
		Address[] adrs = { new Address("ci1", "state1", "country1", 123456),
				new Address("ci2", "state2", "country2", 523456), new Address("ci3", "state3", "country3", 623456),
				new Address("ci4", "state4", "country4", 523456) };
		HashMap<Integer, Emp> hm = new HashMap<>();
		int counter = 0;
		for (Emp e : emps) {
			hm.put(e.getId(), e);
			e.linkAddress(adrs[counter++]);
		}
		return hm;
	}
}
