package utils;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.app.core.Emp;

public class IOUtils {
	public static void storeEmpInfo(List<Emp> l1, String file) throws Exception {
		// create chain of resources
		try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
			l1.forEach(e -> pw.println(e));
		}
	}

	public static List<Emp> restoreEmpInfo(String fileName) throws Exception {
		// file cls instance
		File f1 = new File(fileName);
		if (f1.exists() && f1.isFile() && f1.canRead()) {
			ArrayList<Emp> l1 = new ArrayList<>();
			// attach scanner to file
			try (Scanner sc = new Scanner(f1)) {
				while (sc.hasNextInt())
					l1.add(new Emp(sc.nextInt(), sc.next(), sc.nextDouble()));
				System.out.println("data read over...");
				return l1;
			}
		} else
			return null;

	}
}
