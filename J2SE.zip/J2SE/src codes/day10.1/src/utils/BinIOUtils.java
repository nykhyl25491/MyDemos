package utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import com.app.core.Emp;

public class BinIOUtils {
	// write 1 emp record to bin file
	public static void storeData(Emp e, String fileName) throws Exception {
		// create chain of streams
		try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(fileName)))) {
			// id
			out.writeInt(e.getId());
			// name
			out.writeUTF(e.getName());
			// salary
			out.writeDouble(e.getSalary());

		}
	}

	// restore emp data from bin file
	public static Emp readData(String fileName) throws Exception {
		// validate file name
		File f1 = new File(fileName);
		if (f1.exists() && f1.isFile() && f1.canRead()) {
			// attach suitable strms
			try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(f1))))

			{
				return new Emp(in.readInt(), in.readUTF(), in.readDouble());
			}
		}
		return null;
	}

}
