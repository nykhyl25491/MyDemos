package char_io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;

public class BufferedFileRead {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter file name");
			try (BufferedReader br = new BufferedReader(new FileReader(sc.nextLine()))) {
				String s = null;
				while ((s = br.readLine()) != null)
					System.out.println(s);
				System.out.println("file reading over....");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
