package char_io;

import java.util.List;
import java.util.Scanner;

import com.app.core.Emp;

import static utils.CollectionUtils.*;
import static utils.IOUtils.*;

public class RestoreEmpInfo {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter file name to restore emp info");
			List<Emp> l1 = restoreEmpInfo(sc.nextLine());
			if (l1 != null)
				l1.forEach(e -> System.out.println(e));
			else
				System.out.println("Invalid file name.....");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
