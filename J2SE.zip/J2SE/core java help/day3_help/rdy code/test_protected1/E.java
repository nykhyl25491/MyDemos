package test_protected1;
import test_protected.*;

public class E {
	A a1=new A();
		//	a1.test();
}

