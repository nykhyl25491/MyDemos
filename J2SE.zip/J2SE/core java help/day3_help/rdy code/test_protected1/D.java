package test_protected1;
import test_protected.*;
public class D extends A {

	void show()
	{
	//	A a1=new A();
		test();
	}
}
