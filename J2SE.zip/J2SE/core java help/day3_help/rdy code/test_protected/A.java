package test_protected;

public class A {

	protected void test()
	{
		System.out.println("testing protected scope");
	}
}
