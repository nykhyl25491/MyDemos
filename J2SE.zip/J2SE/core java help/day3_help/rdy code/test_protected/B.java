package test_protected;

public class B extends A {

	void show()
	{
		A a1=new A();
		a1.test();
	}
}
