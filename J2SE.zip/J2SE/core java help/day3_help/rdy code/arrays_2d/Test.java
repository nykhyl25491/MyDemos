package arrays_2d;

import java.util.Arrays;

public class Test {

	public static void main(String[] args) {
		double[][] data=new double[2][3];
		int k=1;
		for(int i=0;i<data.length;i++)
		  for(int j=0;j<data[i].length;j++)
		   data[i][j]=k++;
		System.out.println("Print array contents using for-each");
		for(double[] d : data) //d=data[0]...
		 for(double d1 : d) //d1=d[0]....
		   System.out.println(d1);
		System.out.println("Printing array of refs");
		System.out.println(Arrays.toString(data));
		System.out.println("Print array contents using deepToString");
		System.out.println(Arrays.deepToString(data));
		//what will be mem picture ?
		//dynamic init of array
		int[][] ints={{1,2,3},{10,20,30}};
		System.out.println(Arrays.toString(ints));
		System.out.println(Arrays.deepToString(ints));

	}

}
