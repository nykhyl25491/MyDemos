package arrays_2d;

import java.util.Arrays;

public class AsymmetricArray
{
	public static void main(String[] args)
	{
		int[][]arr = new int[3][];
		arr[ 0 ] = new int[ 2 ];
		arr[ 1 ] = new int[ 3 ];
		arr[ 2 ] = new int[ 4 ];
		int data=1;
		
		for( int i = 0; i < arr.length; ++ i )
		{
			for( int j = 0; j < arr[ i ].length; ++ j )
				arr[i][j]=data++;
		}
		System.out.println(Arrays.toString(arr));
		System.out.println(Arrays.deepToString(arr));
		
	}
}
