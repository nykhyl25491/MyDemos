package enums;

public class TestEnum {

	public static void main(String[] args) {
		Menu m1=Menu.DIMSUM;

	}

}
