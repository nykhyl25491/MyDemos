package tester;

public class TestOverloading {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		test("abc",10,10);

	}
	//widening beats auto-boxing beats var-args
	/*static void test(String s,double d1,double d2)
	{
		System.out.println("1");
	}*/
	/*static void test(String s,int d1,int d2)
	{
		System.out.println("2");
	}*/
	/*static void test(String s,Integer i1,Integer i2)
	{
		System.out.println("3");
	}*/
	static void test(String s,int ... ints)
	{
		System.out.println("4");
	}
	

}
