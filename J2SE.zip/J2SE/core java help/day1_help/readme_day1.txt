WHY Java ?
1. Simple & robust.
2. Platform or architecture independent
3. Secure
4. Automatic memory management.
5. Inherent Multi threaded support
6. Object Oriented support -- Encapsulation,Inheritance & polymorphism
7. Excellent I/O support
8. Inherent networking support for TCP/IP , UDP/IP programming.

------------
Pre-requisites 
0. From terminal
java -version
1. JDK 1.8(Java SE 8)  must be installed using java installer.
2. 1st entry of path must be  (windows instructions)
<JDK1.8>\bin
3. How to set path ?
My Computer --- R Click -- Properties --- Advanced --- Environment variables --- System Variables --- Edit Path --- Add 1st entry as <Java_Home>\bin
DO NOT delete existing path.
Confirm it.
How ?
Open cmd prompt
Type set path
It should show you --path info --- where 1st entry is <Java_Home>\bin .

Type from cmd prompt
java -version


4. Create empty workspace. Create folders day wise. Create src & bin to store java sources & .class files separately.

Rules on Identifiers

1. Identifiers must start with a letter, a currency character ($), or a connecting
character such as the underscore ( _ ),  cannot start with a number!
2. Can't use a Java keyword as an identifier. 
3. Are Case sensitive 

Norms
class , interfaces , enum names-  must start with upper case & then follow camel case
data members/methods(funs) --  must start with lower case & then follow camel case
constants -- all uppercase.


Objective --- Create a java appln to display welcome msg on the console.


Legal class level access specifiers - default(scope=current pkg only), public (scope=accessible form any where)

compiler usage --- javac -d ..\bin First.java--> place the .class files to bin folder



Objective : accept 2 nums as cmd line args , add them & disp the result.



API -- java docs
java.lang  => pkg name  --default
Integer -- class 
public static int parseInt(String s) throws NumberFormatException


Basic rules 
0. Files with no public classes can have a name that does not match any of the classes in the file 
1. A file can have more than one non public class.
2. There can be only one public class per source code file.
3. If there is a public class in a file, the name of the file must match the name
of the public class. For example, a class declared as public class Example { }
must be in a source code file named Example.java.
4.  If the class is part of a package, the package statement must be the first line
in the source code file, before any import statements that may be present.
5. If there are import statements, they must go between the package statement
(if there is one) and the class declaration. If there isn't a package statement,
then the import statement(s) must be the first line(s) in the source code file.
If there are no package or import statements, the class declaration must be
the first line in the source code file.
5. import and package statements apply to all classes within a source code file.
In other words, there's no way to declare multiple classes in a file and have
them in different packages, or use different imports.


--------------------
Regarding primitive types

Automatic conversions(widening ) ---Automatic promotions
byte--->short--->int---> long--->float--->double
char ---> int

long --->float ---is considered automatic type of conversion(since float data type can hold larger range of values that long data type)


Rules ---
src & dest - must be compatible, typically dest data type must be able to store larger magnitude of values than  that of src data type.

Any arithmetic operation involving bytes --- result type=int
Any arithmetic op involving short --- result type=int
int & long ---> long
long & float ---> float
byte,short......& float & double----> double

Narrowing conversion --- forced conversion(type-casting)
eg --- 
double ---> int 
float --> long
double ---> float 
--------------------------

Steps for attaching scanner -- 
What is Scanner ?
A class that represents text based parser(has inherent small ~ 1K buffer)
It can parse text data from any source --Console input,Text file , socket, string

Steps

1. import java.util.*; or import java.util.Scanner;
2. create instance of Scanner class
constr -- Scanner (InputStream in)
System.in --- stdin
usage -- Scanner sc=new Scanner(System.in);
3.To check data type 
boolean hasNextInt(),hasNextByte(),hasNextLong()......

4. To read data
int nextInt() throws InputMismatchException
double nextDouble() throws InputMismatchException
String next(),String nextLine(),boolean nextBoolean()....

-----------------------------------------------

Object oriented principles

Class Programming 

Encapsulation -- consists of Data hiding + Abstraction

Data hiding -- achieved by private data members & supplying public accessors.

Abstraction -- achieved by supplying an interface to the Client (customer) .Highlighting only WHAT is to be done & not highlighting HOW it's internally implemented.


Advantages ---security
ease of maintenance
ease of usage
ensures easy modification




Objective --- Create Java appln for follow. -represent 3D Box----tightly encapsulated class.
Data members -width,height,depth : double --- private


constr-  to init Box params.
Business logic(behaviour) --- displayBoxDetails(void ret) ,calcVolume(ret vol)


Create Java application -- which allows user to supply 3 dims  as user i/ps via scanner. --- create Box object & display dtls & display vol.



Create Java application -- which allows user to supply 3 dims from user using scanner. --- create Box object & display dims & display vol.


------------------------------
Pointers vs java references

pointer arithmatic is not allowed in java.
reference --- holds internal representation of address --

--------------------------------------------

method local vars Vs instance data members
method local vars --- allocated on stack, def. -- uninitialized.
inst. data members --- allocated on heap, inited to def vals(eg - boolean -false,int -0,double 0.0, ref-null)

Javac doesn't allow accessing ANY (prim type or ref type) un-initialized data member.
-------------------------------
Automatic Gargabe Collection --- to avoid mem. leaks/holes

JRE creates 2 thrds --- main thrd(to exec main() sequentially) -- fg thrd
G.C --- daemon thrd ---bg thrd --- gets activated periodically  --- releases the memory occupied by un-referenced objects allocated on the heap(the obj whose no. of ref=0) 
To release/close non- Java resources.(eg - closing of Db conn, closing file handles  is NOT done auto. by GC)
Garbage= un -reachable object.

---------------------------------
Array handling

Array of primitive types

Objective -- Accept no of data samples(double) from User
Create array & display --confirm default values.
Accept data from User(scanner) & store it in suitable array.
Display array data from for loop.
for-each syntax.

Array of References

Objective --- Accept from user --- no of boxes to be made.
Accept box dims from user & display box dims using for-each

--------------------------
Regarding Packages

What is a package ?
Collection of functionally similar classes & interfaces.

Creating user defined packages
Need ?
1. To group functionally similar classes together.
2. Avoids name space collision
3. Finer control over access specifiers.

About Packages 
1. Creation : package stmt has to be placed as the 1st stmt in Java source.
eg : package p1; => the classes will be part of package p1.
2.Package names are mapped to folder names.
eg : package p1; class A{....}
A.class must exist in folder p1.
3.  For simplicity --- create folder p1 -- under <src> & compile from <src>
From <src>
javac -d ..\bin p1\A.java

-> javac will auto. create the sub-folder <p1> under the <bin> folder & place A.class within <p1>



NOTE : Its not mandatory to create java sources(.java) under package named folder. BUT its mandatory to store packged compiled classes(.class) under package named folders

Earlier half is just maintained as convenience(eg --- javac can then detect auto. dependencies & compile classes ).


4. To run the pkged classes from any folder : u must set Java specific  env var. : classpath
set classpath=g:\dac1\day2\bin;

With the classpath set, JVM's classloader 1st searches in the curnt folder, if not found then will continue to search in the folders specified in the classpath & try to load the pkged classes.

classpath= Java only env .var
Used mainly by JRE's classloader : to locate & load the classes.
Classloader will try to locate the classes from current folder, if not found --- will refer to classpath entries : to resolve & load Java classes.

What should be value of classpath ---Must be set to top of pakged hierarchy(i.e .class eg : bin) 
set classpath=G:\dac\dac1\day2\bin;(cmd line invocation)
OR better still
set it from environment variables.
-----------------------------------------------
