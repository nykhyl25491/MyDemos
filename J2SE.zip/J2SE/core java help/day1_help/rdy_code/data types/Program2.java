package com.core.type;

public class Program2
{
	public static void main(String[] args)
	{
		boolean success = true;
		System.out.printf("Success	:	%b\n\n",success);
		
		byte num1 = 125;
		System.out.printf("Num1	:	%d\n\n",num1);
		
		short num2 = 1250;
		System.out.printf("Num2	:	%d\n\n",num2);
		
		char ch ='S';
		System.out.printf("Ch	:	%c\n\n",ch);
		
		int num3 = 123456;
		System.out.printf("Num3	:	%d\n\n",num3);
		
		long num4 = 123456789;
		System.out.printf("Num4	:	%d\n\n",num4);
		
		float num5 = 123.45f;
		System.out.printf("Num5	:	%f\n",num5);
		System.out.printf("Num5	:	%g\n",num5);
		System.out.printf("Num5	:	%e\n\n",num5);
		
		double num6 = 12345.67;
		System.out.printf("Num6	:	%f\n",num6);
		System.out.printf("Num6	:	%g\n",num6);
		System.out.printf("Num6	:	%e\n\n",num6);
		
		String str = "Sadeep Kulkarni";
		System.out.printf("Name	:	%s\n\n", str);
	}
}
