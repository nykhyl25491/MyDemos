Set features
1. Guarantees no duplicate elements(ref)
2. Constant time performance(add,remove,size) ensured via hashing algorithm.(init capa , load factor)
3. Doesn't add any new behaviour.(from Collection i/f) BUT modifies meaning of some of the methods.
4. Allows single null ref.
5. Does not guarantee order of iteration over time.(HashSet)

Implementation classes --- HashSet ---un ordered & unsorted set.
TreeSet -- Sorted set as per either Natural Ordering or Custom ordering.
LinkedHashSet ---remembers order of insertion.

HashSet<E> 
1. HashSet()  --- Creates new empty HS of def init capa=16 & L.F =.75
2. HashSet(int capa)
3. HashSet(int capa,float loadFactor)
4. HashSet(Collection<? extends E> c) --- creates populated HS<E> from ANY Collection(AL,LL,Vector,HS,LHS,TS) of type E or sub type.

eg : HashSet<Emp> emps=new HS<>();
sop(hs.add(e1));
sop(hs.add(e2));
sop(hs.add(e3));





Confirm working of TreeSet constructors.
1. TreeSet<E>() --- new empty TS -- While populating --- TS invokes E's compareTo -- Natural ordering.
2. TreeSet<E>(Collection<? extends E> c) -- new populated set --TS invokes E's compareTo -- Natural ordering.
3. TreeSet(Comparator<? super E> comp) -- new empty TS . While populating ---invokes compare(..) of supplied Comparator class(comp)



Objective 
Create empty Emp set(HS) & populate it.


Regarding Hashing based Data structures....(eg : HashSet,HashTable,HashMap,LiknkedHasSet...)
Steps for Creating HashSet of User defined Type OR HashMap 

1. Business Object class(for HashSet) or Key class in Map world must override : hashCode & equals method both
public int hashCode() --- Object class rets int : which represents internal  addr where obj is sitting on the heap(typically -- specific to JVM internals)
public boolean equals(Object ref) -- Object class rets true : iff 2 refs are referring to the same copy.

2. Rule to observe while overriding these methods 
If 2 refs are equal via equals method then their hashCode values must be same.
eg : If ref1.equals(ref2) ---> true then ref1.hashCode() = ref2.hashCode()
Converse may not be mandatory.(i.e if ref1.equals(ref2) = false then its not mandatory that ref1.hashCode() != ref2.hashCode() : but recommended for better working of hashing based D.S)


Thumb rule -- Use same members (private data members) for overriding equals & hashCode methods 

How does hashing based data structure ensure constant time performance?

If no of entries > capacity * load factor --- re-hashing takes place ---
New data structure is created --(hashtable) -- with approx double the original capacity --- HM takes all earlier entries from orig map & places them in newly created D.S -- using hashCode & equals. -- ensures lesser hash collisions.

Why there is a guarantee that a duplicate entry / ref can't exist in yet another bucket ?
Answer is thanks to the contract between overriding of hashCode & equals methods

If two keys are the same (equals() returns true when you compare them), their hashCode() method must return the same number. If keys violate this, then keys that are equal might be stored in different buckets, and the hashmap would not be able to find key-value pairs (because it's going to look in the same bucket).

If two keys are different(i.e equals method rets false) , then it doesn't matter if their hash codes are the same or not. They will be stored in the same bucket if their hash codes are the same, and in this case, the hashmap will use equals() to tell them apart.








